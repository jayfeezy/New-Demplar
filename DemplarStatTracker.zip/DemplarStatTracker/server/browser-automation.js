// Browser automation to extract Knights character images by simulating human interaction
import puppeteer from 'puppeteer';

export async function extractKnightsImagesByBrowsing() {
  console.log('Starting browser automation to extract Knights character images...');
  
  let browser = null;
  const extractedImages = [];
  
  try {
    // Launch browser with specific options for Replit environment
    browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
        '--disable-gpu'
      ]
    });
    
    const page = await browser.newPage();
    
    // Set viewport and user agent to appear like a real browser
    await page.setViewport({ width: 1366, height: 768 });
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    console.log('Opening knightsofdegen.netlify.app...');
    
    // Navigate to the Knights website
    await page.goto('https://knightsofdegen.netlify.app/', {
      waitUntil: 'networkidle2',
      timeout: 30000
    });
    
    console.log('Page loaded, waiting for React content to render...');
    
    // Wait for character cards to appear (React dynamic content)
    await page.waitForTimeout(3000);
    
    // Look for character cards - try multiple possible selectors
    const cardSelectors = [
      '.character-card',
      '.knight-card',
      '[data-testid="character-card"]',
      '.card',
      '.grid > div',
      '.character',
      '.knight'
    ];
    
    let characterCards = [];
    
    for (const selector of cardSelectors) {
      try {
        await page.waitForSelector(selector, { timeout: 5000 });
        characterCards = await page.$$(selector);
        if (characterCards.length > 0) {
          console.log(`Found ${characterCards.length} character cards using selector: ${selector}`);
          break;
        }
      } catch (error) {
        console.log(`Selector ${selector} not found, trying next...`);
      }
    }
    
    if (characterCards.length === 0) {
      // If no cards found with specific selectors, look for clickable elements with images
      console.log('No character cards found with standard selectors, looking for clickable images...');
      
      characterCards = await page.evaluate(() => {
        const elements = Array.from(document.querySelectorAll('img, div, button, a'));
        return elements
          .filter(el => {
            const rect = el.getBoundingClientRect();
            return rect.width > 50 && rect.height > 50; // Reasonable card size
          })
          .slice(0, 10); // Limit to first 10 potential cards
      });
    }
    
    console.log(`Processing ${characterCards.length} character elements...`);
    
    // Click on each character card and extract image URLs
    for (let i = 0; i < Math.min(characterCards.length, 10); i++) {
      try {
        console.log(`Clicking character card ${i + 1}...`);
        
        // Click the character card
        await characterCards[i].click();
        
        // Wait for modal to appear
        await page.waitForTimeout(2000);
        
        // Look for modal with character image
        const modalSelectors = [
          '.modal img',
          '.popup img',
          '.dialog img',
          '.overlay img',
          '[role="dialog"] img'
        ];
        
        let imageUrl = null;
        
        for (const modalSelector of modalSelectors) {
          try {
            const imageElement = await page.$(modalSelector);
            if (imageElement) {
              imageUrl = await page.evaluate(img => img.src, imageElement);
              if (imageUrl && imageUrl.includes('ctfassets')) {
                console.log(`✓ Found authentic image URL: ${imageUrl}`);
                break;
              }
            }
          } catch (error) {
            // Continue to next selector
          }
        }
        
        // If modal has "Open in new tab" button, click it
        const openTabSelectors = [
          'button[title*="new tab"]',
          'a[target="_blank"]',
          '.open-tab',
          '.new-tab',
          '[aria-label*="new tab"]'
        ];
        
        for (const tabSelector of openTabSelectors) {
          try {
            const openTabButton = await page.$(tabSelector);
            if (openTabButton) {
              console.log('Found "Open in new tab" button, clicking...');
              await openTabButton.click();
              await page.waitForTimeout(1000);
              
              // Check if new tab was opened and get image URL from there
              const pages = await browser.pages();
              if (pages.length > 1) {
                const newTab = pages[pages.length - 1];
                await newTab.waitForSelector('img', { timeout: 5000 });
                const newTabImageUrl = await newTab.evaluate(() => {
                  const img = document.querySelector('img');
                  return img ? img.src : null;
                });
                
                if (newTabImageUrl && newTabImageUrl.includes('ctfassets')) {
                  imageUrl = newTabImageUrl;
                  console.log(`✓ Extracted image from new tab: ${imageUrl}`);
                }
                
                await newTab.close();
              }
              break;
            }
          } catch (error) {
            // Continue to next selector
          }
        }
        
        if (imageUrl) {
          // Try to extract character name
          const characterName = await page.evaluate(() => {
            const nameSelectors = [
              '.character-name',
              '.knight-name',
              '.modal h1',
              '.modal h2',
              '.modal .title',
              'h1', 'h2', 'h3'
            ];
            
            for (const selector of nameSelectors) {
              const element = document.querySelector(selector);
              if (element && element.textContent.trim()) {
                return element.textContent.trim();
              }
            }
            return `Knight #${Date.now()}`;
          });
          
          extractedImages.push({
            name: characterName,
            image: imageUrl,
            source: 'browser_automation'
          });
        }
        
        // Close modal by pressing Escape or clicking close button
        await page.keyboard.press('Escape');
        await page.waitForTimeout(1000);
        
        // Also try clicking close button if modal is still open
        const closeSelectors = ['.close', '.modal-close', '[aria-label="close"]', 'button[type="button"]'];
        for (const closeSelector of closeSelectors) {
          try {
            const closeButton = await page.$(closeSelector);
            if (closeButton) {
              await closeButton.click();
              break;
            }
          } catch (error) {
            // Continue
          }
        }
        
        await page.waitForTimeout(1000);
        
      } catch (error) {
        console.log(`Error processing card ${i + 1}: ${error.message}`);
        continue;
      }
    }
    
    console.log(`Browser automation complete. Extracted ${extractedImages.length} character images.`);
    return extractedImages;
    
  } catch (error) {
    console.error('Browser automation error:', error);
    throw error;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// Alternative method: Extract images from page source without clicking
export async function extractImagesFromPageSource() {
  console.log('Extracting character images from page source...');
  
  let browser = null;
  
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
        '--disable-gpu'
      ]
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 768 });
    
    console.log('Loading Knights website and waiting for images...');
    
    await page.goto('https://knightsofdegen.netlify.app/', {
      waitUntil: 'networkidle2',
      timeout: 30000
    });
    
    // Wait for dynamic content to load
    await page.waitForTimeout(5000);
    
    // Extract all Contentful image URLs from the page
    const imageUrls = await page.evaluate(() => {
      const images = Array.from(document.querySelectorAll('img'));
      const contentfulImages = images
        .map(img => img.src)
        .filter(src => src && src.includes('ctfassets.net'))
        .filter((url, index, array) => array.indexOf(url) === index); // Remove duplicates
      
      return contentfulImages.map(url => ({
        name: `Knight Character`,
        image: url,
        source: 'page_source'
      }));
    });
    
    console.log(`Found ${imageUrls.length} Contentful images in page source`);
    return imageUrls;
    
  } catch (error) {
    console.error('Page source extraction error:', error);
    throw error;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}