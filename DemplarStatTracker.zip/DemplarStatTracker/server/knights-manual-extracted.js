// Knights of Degen characters with manually extracted authentic profile images
// Following the process: knightsofdegen.netlify.app → click character card → top right corner → open in new tab
export const knightsData = [
  { 
    name: "ALEX", 
    playerName: "ALEX", 
    className: "Fairy Berserker", 
    level: 30, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png",
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Lady Rangiku (λ2)", 
    playerName: "Lady Rangiku (λ2)", 
    className: "Blade Healer", 
    level: 40, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg",
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nTraining +5%\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "The Fork Knight (λ2)", 
    playerName: "The Fork Knight (λ2)", 
    className: "Time Traveler", 
    level: 52, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg",
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  // Placeholder entries for manual extraction - add more authentic URLs here
  // ADD MORE KNIGHTS HERE USING MANUAL EXTRACTION PROCESS:
  // 1. Go to https://knightsofdegen.netlify.app/
  // 2. Click character card
  // 3. Top right corner → Open in new tab
  // 4. Copy image URL and replace "MANUAL_EXTRACT_NEEDED" below
  
  { 
    name: "INSPIRED", 
    playerName: "INSPIRED", 
    className: "El Shooter", 
    level: 11, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png",
    notes: "Location: Enchanted Forest\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "CERTIFIEDLOVERBULL", 
    playerName: "CERTIFIEDLOVERBULL", 
    className: "Korathax, Golden Titan", 
    level: 16, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Labyrinth\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Tommy", 
    playerName: "Tommy", 
    className: "Flame Assassin", 
    level: 17, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Compression of Time\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "True Warrior", 
    playerName: "True Warrior", 
    className: "Ul'Zareth, Crown of the Dying Suns", 
    level: 10, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Labyrinth\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "DENOJAH", 
    playerName: "DENOJAH", 
    className: "PIP CAPTAIN", 
    level: 26, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Kingdom\nCard Type: wPond\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Sir Nemo [AI]", 
    playerName: "Sir Nemo [AI]", 
    className: "Demplar Samurai", 
    level: 31, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Compression of Time\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "MDK", 
    playerName: "MDK", 
    className: "Pond Enigma", 
    level: 11, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Labyrinth\nCard Type: wPond\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "American Hearts", 
    playerName: "American Hearts", 
    className: "Phunk Knight", 
    level: 9, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Library\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Chair", 
    playerName: "Chair", 
    className: "Phunk Knight", 
    level: 14, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "JEST", 
    playerName: "JEST", 
    className: "Jester", 
    level: 12, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Watchtower\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Meggy", 
    playerName: "Meggy", 
    className: "Counter Culture 0 Martial Artist", 
    level: 17, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Thieves Den\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "W!¢KغD", 
    playerName: "W!¢KغD", 
    className: "Jerks Adventurer", 
    level: 10, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Library\nCard Type: Demplar\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Ponderer", 
    playerName: "Ponderer", 
    className: "Steampunk", 
    level: 11, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: wPond\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "2NA", 
    playerName: "2NA", 
    className: "Mercenary", 
    level: 8, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "🩸Ǝ", 
    playerName: "🩸Ǝ", 
    className: "Vampire Ninja", 
    level: 18, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Yoss0x", 
    playerName: "Yoss0x", 
    className: "Phunk Knight", 
    level: 12, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Sizzler", 
    playerName: "Sizzler", 
    className: "Comrade Knight", 
    level: 12, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Luminous\nCard Type: Pork\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "MCO WOLF (λ2)", 
    playerName: "MCO WOLF (λ2)", 
    className: "Bloodmoon Reaver", 
    level: 23, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Kingdom\nCard Type: wPond\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "IFiHAD", 
    playerName: "IFiHAD", 
    className: "Mystic Troubadour", 
    level: 10, 
    avatarUrl: "MANUAL_EXTRACT_NEEDED",
    notes: "Location: Shmiffin Shmoffin Quarry\nCard Type: wPond\nAuthentic Knights of Degen member", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  }
];