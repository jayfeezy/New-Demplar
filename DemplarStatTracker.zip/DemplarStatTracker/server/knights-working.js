// Working Knights of Degen character data with verified working image URLs
export const knightsData = [
  { 
    name: "ALEX", 
    playerName: "ALEX", 
    className: "Fairy Berserker", 
    level: 30, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", 
    notes: "Location: Luminous\nCard Type: Demplar\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Sparrow (λ2)", 
    playerName: "Sparrow (λ2)", 
    className: "Solo Warden", 
    level: 41, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/2U1E47ykOAEfOhf3Iv2kKu/0e3c7ddeba7cfc84b6c2a02cd14b3456/image.png", 
    notes: "Location: Luminous\nCard Type: wPond\nTraining +5%\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Lady Rangiku (λ2)", 
    playerName: "Lady Rangiku (λ2)", 
    className: "Blade Healer", 
    level: 40, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", 
    notes: "Location: Luminous\nCard Type: Demplar\nTraining +5%\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "The Fork Knight (λ2)", 
    playerName: "The Fork Knight (λ2)", 
    className: "Time Traveler", 
    level: 52, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", 
    notes: "Location: Luminous\nCard Type: Demplar\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "DENOJAH", 
    playerName: "DENOJAH", 
    className: "PIP CAPTAIN", 
    level: 26, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/3GDX7CX5yvgPD8ygbhY4a7/0e87dbc5c4b17a7fdd6bb7cf8e6e0f33/DENOJAH.jpg", 
    notes: "Location: Kingdom\nCard Type: wPond\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "INSPIRED", 
    playerName: "INSPIRED", 
    className: "El Shooter", 
    level: 11, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/6UXNghlb7FrBc6n5AciuZB/ae6c5591991342fa1a54439277ca77ab/JHgR4XY9.jpg", 
    notes: "Location: Enchanted Forest\nCard Type: Pork\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "CERTIFIEDLOVERBULL", 
    playerName: "CERTIFIEDLOVERBULL", 
    className: "Korathax, Golden Titan", 
    level: 16, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/7vwNAkr4ioZfgq9iH8epNE/b7d09af9b63d44b7c88c7b94a97816b2/Certified_Lover_Bull.jpg", 
    notes: "Location: Labyrinth\nCard Type: Demplar\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Tommy", 
    playerName: "Tommy", 
    className: "Flame Assasin", 
    level: 17, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", 
    notes: "Location: Compression of Time\nCard Type: Demplar\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "True Warrior", 
    playerName: "True Warrior", 
    className: "Ul'Zareth, Crown of the Dying Suns", 
    level: 10, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/5rKZVrCb5l8rpZ4MQLrYuV/9df8e0b40a3ffeceb0b956e8b7af0e22/True_Warrior.jpg", 
    notes: "Location: Labyrinth\nCard Type: Demplar\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, constitution: 55, dexterity: 55, luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  }
];