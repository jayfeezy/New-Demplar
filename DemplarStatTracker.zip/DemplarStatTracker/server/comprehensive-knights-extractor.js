// Comprehensive Knights character extraction from knightsofdegen.netlify.app
import https from 'https';
import { URL } from 'url';

export async function extractAllKnightsCharacters() {
  console.log('Starting comprehensive Knights character extraction...');
  
  try {
    // First get the main page to find JavaScript bundles
    const mainPageHtml = await fetchURL('https://knightsofdegen.netlify.app/');
    const jsUrls = extractJavaScriptURLs(mainPageHtml);
    
    console.log(`Found ${jsUrls.length} JavaScript files to analyze`);
    
    const allCharacters = new Map(); // Use Map to avoid duplicates
    
    // Analyze each JavaScript bundle
    for (const jsUrl of jsUrls) {
      try {
        console.log(`Analyzing: ${jsUrl}`);
        const jsContent = await fetchURL(jsUrl);
        
        // Extract character data from JavaScript
        const characters = await extractCharactersFromJS(jsContent);
        
        characters.forEach(char => {
          if (char.image && char.image.includes('ctfassets.net')) {
            allCharacters.set(char.image, char);
          }
        });
        
      } catch (error) {
        console.log(`Failed to analyze ${jsUrl}: ${error.message}`);
      }
    }
    
    // Try alternative extraction methods
    console.log('Attempting direct pattern matching...');
    const directCharacters = await extractByPatternMatching();
    directCharacters.forEach(char => {
      if (char.image && char.image.includes('ctfassets.net')) {
        allCharacters.set(char.image, char);
      }
    });
    
    const finalCharacters = Array.from(allCharacters.values());
    console.log(`Total unique characters extracted: ${finalCharacters.length}`);
    
    return finalCharacters;
    
  } catch (error) {
    console.error('Comprehensive extraction error:', error);
    throw error;
  }
}

function fetchURL(url) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname + urlObj.search,
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive'
      },
      timeout: 15000
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
        // Prevent memory issues
        if (data.length > 10000000) { // 10MB limit
          res.destroy();
          reject(new Error('Response too large'));
        }
      });
      
      res.on('end', () => {
        if (res.statusCode === 200) {
          resolve(data);
        } else {
          reject(new Error(`HTTP ${res.statusCode}`));
        }
      });
    });
    
    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    
    req.end();
  });
}

function extractJavaScriptURLs(html) {
  const jsUrls = [];
  
  // Extract script src attributes
  const scriptRegex = /<script[^>]+src="([^"]+)"[^>]*>/g;
  let match;
  
  while ((match = scriptRegex.exec(html)) !== null) {
    let url = match[1];
    
    // Convert relative URLs to absolute
    if (url.startsWith('/')) {
      url = 'https://knightsofdegen.netlify.app' + url;
    } else if (url.startsWith('./')) {
      url = 'https://knightsofdegen.netlify.app/' + url.substring(2);
    }
    
    // Include all JavaScript files
    if (url.includes('.js')) {
      jsUrls.push(url);
    }
  }
  
  return jsUrls;
}

async function extractCharactersFromJS(jsContent) {
  const characters = [];
  
  try {
    // Look for Contentful URLs in various patterns
    const contentfulPatterns = [
      /https:\/\/images\.ctfassets\.net\/b474hutgbdbv\/[a-zA-Z0-9]+\/[a-zA-Z0-9]+\/[^"'\s]+\.(jpg|png|webp|jpeg)/g,
      /"(https:\/\/images\.ctfassets\.net\/[^"]+)"/g,
      /'(https:\/\/images\.ctfassets\.net\/[^']+)'/g
    ];
    
    const foundUrls = new Set();
    
    for (const pattern of contentfulPatterns) {
      let match;
      while ((match = pattern.exec(jsContent)) !== null) {
        const url = match[1] || match[0];
        if (url.includes('ctfassets.net') && (url.includes('.jpg') || url.includes('.png') || url.includes('.webp'))) {
          foundUrls.add(url.replace(/^["']|["']$/g, ''));
        }
      }
    }
    
    // Look for character names that might be associated with these URLs
    const namePatterns = [
      /"name":\s*"([^"]+)"/g,
      /"title":\s*"([^"]+)"/g,
      /"playerName":\s*"([^"]+)"/g,
      /name:\s*"([^"]+)"/g,
      /title:\s*"([^"]+)"/g
    ];
    
    const foundNames = [];
    for (const pattern of namePatterns) {
      let match;
      while ((match = pattern.exec(jsContent)) !== null) {
        const name = match[1];
        if (name && name.length > 1 && !name.includes('http') && !name.includes('.js')) {
          foundNames.push(name);
        }
      }
    }
    
    // Look for class names
    const classPatterns = [
      /"className":\s*"([^"]+)"/g,
      /"class":\s*"([^"]+)"/g,
      /className:\s*"([^"]+)"/g
    ];
    
    const foundClasses = [];
    for (const pattern of classPatterns) {
      let match;
      while ((match = pattern.exec(jsContent)) !== null) {
        const className = match[1];
        if (className && className.length > 1 && !className.includes('css') && !className.includes('style')) {
          foundClasses.push(className);
        }
      }
    }
    
    // Combine URLs with names
    const urlArray = Array.from(foundUrls);
    urlArray.forEach((url, index) => {
      const name = foundNames[index] || foundNames[index % foundNames.length] || `Knight Character ${index + 1}`;
      const className = foundClasses[index] || foundClasses[index % foundClasses.length] || 'Unknown Class';
      
      characters.push({
        name: name,
        image: url,
        className: className,
        source: 'javascript_extraction',
        extractionIndex: index
      });
    });
    
  } catch (error) {
    console.log('JavaScript parsing error:', error.message);
  }
  
  return characters;
}

async function extractByPatternMatching() {
  console.log('Attempting pattern-based character extraction...');
  
  const characters = [];
  
  // Known Contentful asset patterns from the existing data
  const knownAssetIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT', 
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  // Generate variations around known patterns
  const assetIdVariations = generateAssetIdVariations(knownAssetIds);
  const hashVariations = generateHashVariations(knownHashes);
  
  console.log(`Testing ${assetIdVariations.length} asset ID variations...`);
  
  const workingUrls = [];
  
  // Test asset ID variations
  for (let i = 0; i < Math.min(assetIdVariations.length, 100); i++) {
    const assetId = assetIdVariations[i];
    
    for (let j = 0; j < Math.min(hashVariations.length, 10); j++) {
      const hash = hashVariations[j];
      
      const testUrls = [
        `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/image.png`,
        `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/knight.jpg`,
        `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/character.png`,
        `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/avatar.jpg`
      ];
      
      for (const url of testUrls) {
        try {
          const isValid = await testImageURL(url);
          if (isValid) {
            workingUrls.push(url);
            console.log(`✓ Found working URL: ${url}`);
            
            characters.push({
              name: `Knight Character ${workingUrls.length}`,
              image: url,
              className: 'Unknown Class',
              source: 'pattern_matching'
            });
          }
        } catch (error) {
          // Continue testing
        }
      }
    }
  }
  
  return characters;
}

function generateAssetIdVariations(knownIds) {
  const variations = [...knownIds];
  
  // Generate similar patterns
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  
  for (const id of knownIds) {
    // Create variations by changing last few characters
    for (let i = 0; i < 5; i++) {
      let variation = id.slice(0, -2);
      variation += chars[Math.floor(Math.random() * chars.length)];
      variation += chars[Math.floor(Math.random() * chars.length)];
      variations.push(variation);
    }
  }
  
  return variations;
}

function generateHashVariations(knownHashes) {
  const variations = [...knownHashes];
  
  const hexChars = '0123456789abcdef';
  
  for (const hash of knownHashes) {
    // Create variations by changing last few characters
    for (let i = 0; i < 5; i++) {
      let variation = hash.slice(0, -4);
      for (let j = 0; j < 4; j++) {
        variation += hexChars[Math.floor(Math.random() * hexChars.length)];
      }
      variations.push(variation);
    }
  }
  
  return variations;
}

function testImageURL(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname + urlObj.search,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; ImageBot/1.0)'
      },
      timeout: 3000
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}