// Verified Knights of Degen characters with working profile images from knightsofdegen.netlify.app
// These are the only confirmed working image URLs from the Knights website
export const knightsData = [
  { 
    name: "ALEX", 
    playerName: "ALEX", 
    className: "Fairy Berserker", 
    level: 30, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", 
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, 
    constitution: 55, 
    dexterity: 55, 
    luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "Lady Rangiku (λ2)", 
    playerName: "Lady Rangiku (λ2)", 
    className: "Blade Healer", 
    level: 40, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", 
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nTraining +5%\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, 
    constitution: 55, 
    dexterity: 55, 
    luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  },
  { 
    name: "The Fork Knight (λ2)", 
    playerName: "The Fork Knight (λ2)", 
    className: "Time Traveler", 
    level: 52, 
    avatarUrl: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", 
    notes: "Location: Luminous\nCard Type: Demplar\nAuthentic Knights of Degen member\nCard Buffs: +5% attack, +5% defense, +5% agility, +5% critical, +5% luck, +5% magic defense", 
    strength: 55, 
    constitution: 55, 
    dexterity: 55, 
    luck: 55, 
    customStats: { "Critical": 55, "Magic Defense": 55 } 
  }
];