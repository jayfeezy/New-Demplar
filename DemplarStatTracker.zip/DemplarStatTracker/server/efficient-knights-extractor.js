// Efficient Knights character extraction using known patterns and systematic discovery
import https from 'https';

export async function extractAllKnightsSystematically() {
  console.log('Starting systematic Knights character extraction...');
  
  const workingCharacters = [];
  const baseSpaceId = 'b474hutgbdbv';
  
  // Start with known working patterns from manually extracted data
  const knownWorkingAssets = [
    { id: '2V3dKNSD41QjeLowfolcG3', hash: 'e9a4eb087190d640b9c6c982a17480d4', file: 'image.png', name: 'ALEX' },
    { id: '3AYkauQlVdSQfVvdWtmaT', hash: '895be1409a709d60553bb820c213d45f', file: 'Rangiku.jpg', name: 'Lady Rangiku' },
    { id: '6NXglOf0VcEyW0X6W0umnp', hash: 'f6be1ff12713c114ecd0ba405a52c47f', file: 'Fork-JFSgen2.jpg', name: 'The Fork Knight' },
    { id: '1gmbAGrcfb0LJEhHP7YsNF', hash: '0892ed7d6ce14bc0ab30cb105981a55c', file: 'image.png', name: 'INSPIRED' }
  ];
  
  // Add known working characters first
  for (const asset of knownWorkingAssets) {
    const url = `https://images.ctfassets.net/${baseSpaceId}/${asset.id}/${asset.hash}/${asset.file}`;
    workingCharacters.push({
      name: asset.name,
      image: url,
      source: 'known_working'
    });
  }
  
  console.log(`Added ${workingCharacters.length} known working characters`);
  
  // Generate systematic variations around known working patterns
  const additionalCharacters = await discoverSimilarAssets(knownWorkingAssets, baseSpaceId);
  workingCharacters.push(...additionalCharacters);
  
  console.log(`Total characters found: ${workingCharacters.length}`);
  return workingCharacters;
}

async function discoverSimilarAssets(knownAssets, spaceId) {
  const discoveredCharacters = [];
  
  // Generate asset ID variations based on known patterns
  const assetIdVariations = generateSmartAssetIdVariations(knownAssets.map(a => a.id));
  
  // Generate hash variations
  const hashVariations = generateSmartHashVariations(knownAssets.map(a => a.hash));
  
  // Common file extensions and names
  const fileVariations = [
    'image.png', 'image.jpg', 'knight.png', 'knight.jpg', 'character.png', 'character.jpg',
    'avatar.png', 'avatar.jpg', 'profile.png', 'profile.jpg'
  ];
  
  console.log(`Testing ${assetIdVariations.length} asset variations with ${hashVariations.length} hash variations...`);
  
  let tested = 0;
  const maxTests = 200; // Reasonable limit
  
  for (let i = 0; i < Math.min(assetIdVariations.length, 50) && tested < maxTests; i++) {
    const assetId = assetIdVariations[i];
    
    for (let j = 0; j < Math.min(hashVariations.length, 10) && tested < maxTests; j++) {
      const hash = hashVariations[j];
      
      for (const fileName of fileVariations) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            console.log(`✓ Found new character: ${testUrl}`);
            discoveredCharacters.push({
              name: `Knight Character ${discoveredCharacters.length + 1}`,
              image: testUrl,
              source: 'systematic_discovery'
            });
          }
        } catch (error) {
          // Continue testing
        }
        
        // Small delay to avoid overwhelming the server
        if (tested % 20 === 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
  }
  
  console.log(`Systematic discovery tested ${tested} URLs, found ${discoveredCharacters.length} new characters`);
  return discoveredCharacters;
}

function generateSmartAssetIdVariations(knownIds) {
  const variations = [...knownIds];
  
  // Analyze patterns in known IDs
  for (const id of knownIds) {
    // Create variations by modifying characters systematically
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    
    // Modify last character
    for (let i = 0; i < chars.length; i++) {
      variations.push(id.slice(0, -1) + chars[i]);
    }
    
    // Modify second to last character
    for (let i = 0; i < Math.min(chars.length, 10); i++) {
      variations.push(id.slice(0, -2) + chars[i] + id.slice(-1));
    }
    
    // Increment numeric parts
    const numericMatch = id.match(/(\d+)/);
    if (numericMatch) {
      const num = parseInt(numericMatch[1]);
      for (let i = 1; i <= 5; i++) {
        const newId = id.replace(numericMatch[1], (num + i).toString());
        variations.push(newId);
        const newId2 = id.replace(numericMatch[1], (num - i).toString());
        if (num - i > 0) variations.push(newId2);
      }
    }
  }
  
  // Remove duplicates
  return [...new Set(variations)];
}

function generateSmartHashVariations(knownHashes) {
  const variations = [...knownHashes];
  
  for (const hash of knownHashes) {
    const hexChars = '0123456789abcdef';
    
    // Modify last few characters
    for (let i = 0; i < 16; i++) {
      let variation = hash.slice(0, -1) + hexChars[i];
      variations.push(variation);
    }
    
    // Modify multiple characters at the end
    for (let i = 0; i < 16; i++) {
      for (let j = 0; j < 16; j++) {
        let variation = hash.slice(0, -2) + hexChars[i] + hexChars[j];
        variations.push(variation);
      }
    }
    
    // Increment/decrement hex values
    try {
      const lastByte = parseInt(hash.slice(-2), 16);
      for (let i = 1; i <= 10; i++) {
        const newByte = (lastByte + i) % 256;
        const newHash = hash.slice(0, -2) + newByte.toString(16).padStart(2, '0');
        variations.push(newHash);
        
        const newByte2 = (lastByte - i + 256) % 256;
        const newHash2 = hash.slice(0, -2) + newByte2.toString(16).padStart(2, '0');
        variations.push(newHash2);
      }
    } catch (error) {
      // Continue with other variations
    }
  }
  
  // Remove duplicates
  return [...new Set(variations)];
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; KnightsExtractor/1.0)'
      },
      timeout: 2000
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Enhanced character name extraction from known Knights data
export async function enrichCharactersWithKnownData() {
  const { knightsData } = await import('./knights-manual-extracted.js');
  
  const enrichedCharacters = [];
  
  for (const knight of knightsData) {
    if (knight.avatarUrl && knight.avatarUrl.includes('ctfassets.net') && 
        !knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')) {
      
      enrichedCharacters.push({
        name: knight.name,
        playerName: knight.playerName,
        className: knight.className,
        level: knight.level,
        image: knight.avatarUrl,
        notes: knight.notes,
        strength: knight.strength,
        constitution: knight.constitution,
        dexterity: knight.dexterity,
        luck: knight.luck,
        customStats: knight.customStats,
        source: 'manual_extraction_verified'
      });
    }
  }
  
  return enrichedCharacters;
}