// Complete Knights character extraction using multiple discovery methods
import https from 'https';

export async function extractAllKnightsComplete() {
  console.log('Starting complete Knights character extraction...');
  
  const allCharacters = [];
  const foundUrls = new Set();
  
  // Method 1: Get verified characters
  const verifiedCharacters = await getVerifiedCharacters();
  for (const char of verifiedCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  // Method 2: Systematic asset ID discovery
  const discoveredCharacters = await systematicAssetDiscovery();
  for (const char of discoveredCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  // Method 3: Hash variation discovery
  const hashVariationCharacters = await hashVariationDiscovery();
  for (const char of hashVariationCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  // Method 4: Pattern-based discovery
  const patternCharacters = await patternBasedDiscovery();
  for (const char of patternCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  console.log(`Complete extraction found ${allCharacters.length} unique Knights characters`);
  return allCharacters;
}

async function getVerifiedCharacters() {
  return [
    { name: "ALEX", image: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", className: "Fairy Berserker", level: 30, source: "verified" },
    { name: "Lady Rangiku (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", className: "Blade Healer", level: 40, source: "verified" },
    { name: "The Fork Knight (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", className: "Time Traveler", level: 52, source: "verified" },
    { name: "INSPIRED", image: "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png", className: "El Shooter", level: 11, source: "verified" }
  ];
}

async function systematicAssetDiscovery() {
  console.log('Running systematic asset ID discovery...');
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Known working asset ID patterns
  const knownAssetIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT',
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  // Generate asset ID variations by modifying known patterns
  const assetVariations = [];
  
  for (const baseId of knownAssetIds) {
    // Try incrementing/decrementing numbers in the asset ID
    const numbers = baseId.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        const numVal = parseInt(num);
        for (let delta = -10; delta <= 10; delta++) {
          if (delta !== 0) {
            const newNum = numVal + delta;
            if (newNum > 0) {
              const newId = baseId.replace(num, newNum.toString());
              assetVariations.push(newId);
            }
          }
        }
      }
    }
    
    // Try character substitutions at different positions
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for (let pos = 0; pos < baseId.length; pos++) {
      for (let i = 0; i < 20; i++) { // Test 20 variations per position
        const randomChar = chars[Math.floor(Math.random() * chars.length)];
        const newId = baseId.substring(0, pos) + randomChar + baseId.substring(pos + 1);
        assetVariations.push(newId);
      }
    }
  }
  
  // Test variations with known working hashes
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  const fileNames = ['image.png', 'image.jpg', 'knight.png', 'character.jpg', 'avatar.png'];
  
  let tested = 0;
  const maxTests = 200;
  
  for (const assetId of assetVariations) {
    if (tested >= maxTests) break;
    
    for (const hash of knownHashes) {
      if (tested >= maxTests) break;
      
      for (const fileName of fileNames) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            console.log(`✓ Found asset variation: ${testUrl}`);
            characters.push({
              name: `Knight Asset ${characters.length + 1}`,
              image: testUrl,
              source: 'asset_discovery'
            });
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 50 === 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
  }
  
  console.log(`Asset discovery: tested ${tested} URLs, found ${characters.length} new characters`);
  return characters;
}

async function hashVariationDiscovery() {
  console.log('Running hash variation discovery...');
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Use known working asset IDs with hash variations
  const knownAssetIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT',
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  // Generate hash variations
  const hashVariations = [];
  const hexChars = '0123456789abcdef';
  
  for (const baseHash of knownHashes) {
    // Modify last 2 characters
    for (let i = 0; i < 256; i++) {
      const newHash = baseHash.substring(0, baseHash.length - 2) + i.toString(16).padStart(2, '0');
      hashVariations.push(newHash);
    }
    
    // Modify middle section
    for (let i = 0; i < 50; i++) {
      let newHash = baseHash.substring(0, 16);
      for (let j = 0; j < 4; j++) {
        newHash += hexChars[Math.floor(Math.random() * 16)];
      }
      newHash += baseHash.substring(20);
      hashVariations.push(newHash);
    }
  }
  
  const fileNames = ['image.png', 'image.jpg', 'knight.jpg', 'character.png'];
  
  let tested = 0;
  const maxTests = 300;
  
  for (const assetId of knownAssetIds) {
    if (tested >= maxTests) break;
    
    for (const hash of hashVariations) {
      if (tested >= maxTests) break;
      
      for (const fileName of fileNames) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            console.log(`✓ Found hash variation: ${testUrl}`);
            characters.push({
              name: `Knight Hash ${characters.length + 1}`,
              image: testUrl,
              source: 'hash_discovery'
            });
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 100 === 0) {
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
    }
  }
  
  console.log(`Hash discovery: tested ${tested} URLs, found ${characters.length} new characters`);
  return characters;
}

async function patternBasedDiscovery() {
  console.log('Running pattern-based discovery...');
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Generate completely new asset ID patterns based on observed structure
  const newAssetIds = [];
  
  // Pattern: digit + alphanumeric + specific endings
  const prefixes = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const suffixes = ['G3', 'NF', 'nP', 'aT', 'SD', 'Of', 'mb', 'YK'];
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  
  for (const prefix of prefixes) {
    for (const suffix of suffixes) {
      for (let i = 0; i < 10; i++) {
        let assetId = prefix;
        
        // Generate middle part (18 characters to match known pattern length)
        for (let j = 0; j < 18; j++) {
          assetId += chars[Math.floor(Math.random() * chars.length)];
        }
        
        assetId += suffix;
        newAssetIds.push(assetId);
      }
    }
  }
  
  // Generate new hash patterns
  const newHashes = [];
  const hexChars = '0123456789abcdef';
  
  for (let i = 0; i < 100; i++) {
    let hash = '';
    for (let j = 0; j < 32; j++) {
      hash += hexChars[Math.floor(Math.random() * 16)];
    }
    newHashes.push(hash);
  }
  
  const fileNames = ['image.png', 'image.jpg', 'knight.png', 'avatar.jpg'];
  
  let tested = 0;
  const maxTests = 200;
  
  for (const assetId of newAssetIds) {
    if (tested >= maxTests) break;
    
    for (const hash of newHashes.slice(0, 2)) { // Test only 2 hashes per asset ID
      if (tested >= maxTests) break;
      
      for (const fileName of fileNames) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            console.log(`✓ Found pattern match: ${testUrl}`);
            characters.push({
              name: `Knight Pattern ${characters.length + 1}`,
              image: testUrl,
              source: 'pattern_discovery'
            });
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 50 === 0) {
          await new Promise(resolve => setTimeout(resolve, 150));
        }
      }
    }
  }
  
  console.log(`Pattern discovery: tested ${tested} URLs, found ${characters.length} new characters`);
  return characters;
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; KnightsBot/1.0)'
      },
      timeout: 1000
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}