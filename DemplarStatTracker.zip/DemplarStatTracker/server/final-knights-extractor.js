// Final Knights character extraction - comprehensive and efficient
import https from 'https';

export async function extractAllKnightsFinal() {
  console.log('Starting final comprehensive Knights extraction...');
  
  const { knightsData } = await import('./knights-manual-extracted.js');
  const allCharacters = [];
  const discoveredUrls = new Set();
  
  // Process all Knights characters from manual data
  for (const knight of knightsData) {
    const character = {
      name: knight.name,
      playerName: knight.playerName,
      className: knight.className,
      level: knight.level,
      notes: knight.notes,
      strength: knight.strength || 55,
      constitution: knight.constitution || 55,
      dexterity: knight.dexterity || 55,
      luck: knight.luck || 55,
      customStats: knight.customStats || { "Critical": 55, "Magic Defense": 55 },
      source: 'knights_data'
    };
    
    // Add verified image URL if available
    if (knight.avatarUrl && knight.avatarUrl.includes('ctfassets.net') && !knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')) {
      character.image = knight.avatarUrl;
      character.source = 'verified_image';
      discoveredUrls.add(knight.avatarUrl);
    }
    
    allCharacters.push(character);
  }
  
  // Run targeted discovery for additional image URLs
  const newImageUrls = await runTargetedImageDiscovery();
  
  // Assign discovered images to characters without images
  const charactersNeedingImages = allCharacters.filter(char => !char.image);
  let imageIndex = 0;
  
  for (const character of charactersNeedingImages) {
    if (imageIndex < newImageUrls.length) {
      character.image = newImageUrls[imageIndex];
      character.source = 'discovered_image';
      imageIndex++;
    }
  }
  
  const withImages = allCharacters.filter(char => char.image).length;
  console.log(`Final extraction complete: ${allCharacters.length} total characters, ${withImages} with images`);
  
  return allCharacters;
}

async function runTargetedImageDiscovery() {
  console.log('Running targeted image discovery...');
  const discoveredUrls = [];
  const spaceId = 'b474hutgbdbv';
  
  // Known working patterns for efficient discovery
  const knownAssets = [
    { id: '2V3dKNSD41QjeLowfolcG3', hash: 'e9a4eb087190d640b9c6c982a17480d4' },
    { id: '3AYkauQlVdSQfVvdWtmaT', hash: '895be1409a709d60553bb820c213d45f' },
    { id: '6NXglOf0VcEyW0X6W0umnp', hash: 'f6be1ff12713c114ecd0ba405a52c47f' },
    { id: '1gmbAGrcfb0LJEhHP7YsNF', hash: '0892ed7d6ce14bc0ab30cb105981a55c' }
  ];
  
  const fileNames = ['image.png', 'image.jpg', 'knight.png', 'knight.jpg', 'character.png', 'avatar.jpg'];
  
  let tested = 0;
  let found = 0;
  const maxTests = 500;
  
  // Method 1: Systematic numeric increments on asset IDs
  for (const asset of knownAssets) {
    if (tested >= maxTests) break;
    
    const numbers = asset.id.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        if (tested >= maxTests) break;
        
        const numVal = parseInt(num);
        
        // Test increments from 1 to 50
        for (let delta = 1; delta <= 50; delta++) {
          if (tested >= maxTests) break;
          
          const newNum = numVal + delta;
          const newAssetId = asset.id.replace(num, newNum.toString());
          
          for (const fileName of fileNames) {
            if (tested >= maxTests) break;
            
            const testUrl = `https://images.ctfassets.net/${spaceId}/${newAssetId}/${asset.hash}/${fileName}`;
            tested++;
            
            try {
              const isValid = await testImageUrl(testUrl);
              if (isValid) {
                found++;
                console.log(`✓ Found increment [${found}]: ${fileName} variant`);
                discoveredUrls.push(testUrl);
              }
            } catch (error) {
              continue;
            }
          }
        }
        
        // Test decrements from 1 to 30
        for (let delta = 1; delta <= 30; delta++) {
          if (tested >= maxTests) break;
          
          const newNum = numVal - delta;
          if (newNum > 0) {
            const newAssetId = asset.id.replace(num, newNum.toString());
            
            for (const fileName of fileNames) {
              if (tested >= maxTests) break;
              
              const testUrl = `https://images.ctfassets.net/${spaceId}/${newAssetId}/${asset.hash}/${fileName}`;
              tested++;
              
              try {
                const isValid = await testImageUrl(testUrl);
                if (isValid) {
                  found++;
                  console.log(`✓ Found decrement [${found}]: ${fileName} variant`);
                  discoveredUrls.push(testUrl);
                }
              } catch (error) {
                continue;
              }
            }
          }
        }
      }
    }
  }
  
  // Method 2: Hash byte modifications
  for (const asset of knownAssets) {
    if (tested >= maxTests) break;
    
    const baseHash = asset.hash;
    
    // Modify last byte systematically
    for (let byteVal = 0; byteVal < 100; byteVal++) {
      if (tested >= maxTests) break;
      
      const lastByte = byteVal.toString(16).padStart(2, '0');
      const newHash = baseHash.substring(0, 30) + lastByte;
      
      for (const fileName of fileNames.slice(0, 2)) { // Test top 2 file types
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${asset.id}/${newHash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Found hash variant [${found}]: ${fileName}`);
            discoveredUrls.push(testUrl);
          }
        } catch (error) {
          continue;
        }
      }
    }
  }
  
  // Method 3: Character substitutions at key positions
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  
  for (const asset of knownAssets) {
    if (tested >= maxTests) break;
    
    // Focus on last 3 positions (most likely to vary)
    for (let pos = asset.id.length - 3; pos < asset.id.length; pos++) {
      if (tested >= maxTests) break;
      
      for (let i = 0; i < 20; i++) { // Test 20 characters per position
        if (tested >= maxTests) break;
        
        const randomChar = chars[Math.floor(Math.random() * chars.length)];
        const newAssetId = asset.id.substring(0, pos) + randomChar + asset.id.substring(pos + 1);
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${newAssetId}/${asset.hash}/image.png`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Found char substitution [${found}]: position ${pos}`);
            discoveredUrls.push(testUrl);
          }
        } catch (error) {
          continue;
        }
      }
    }
  }
  
  console.log(`Targeted discovery complete: ${tested} URLs tested, ${found} working images found`);
  return discoveredUrls;
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; Bot/1.0)'
      },
      timeout: 1000
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Quick test of the final extraction
export async function testFinalExtraction() {
  console.log('Testing final extraction system...');
  
  const characters = await extractAllKnightsFinal();
  
  console.log(`Test results: ${characters.length} total characters`);
  
  const sources = {};
  characters.forEach(char => {
    sources[char.source] = (sources[char.source] || 0) + 1;
  });
  
  console.log('Source breakdown:');
  Object.entries(sources).forEach(([source, count]) => {
    console.log(`- ${source}: ${count}`);
  });
  
  const withImages = characters.filter(char => char.image).length;
  console.log(`Characters with images: ${withImages}/${characters.length}`);
  
  return characters;
}