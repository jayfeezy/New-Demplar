// Focused Knights character extraction using precise pattern analysis
import https from 'https';

export async function extractAllKnightsFocused() {
  console.log('Starting focused Knights character extraction...');
  
  const allCharacters = [];
  const foundUrls = new Set();
  
  // Add verified characters
  const verifiedCharacters = getVerifiedCharacters();
  for (const char of verifiedCharacters) {
    allCharacters.push(char);
    foundUrls.add(char.image);
  }
  
  // Focus on incremental discovery around known working patterns
  const incrementalCharacters = await incrementalDiscovery();
  
  for (const char of incrementalCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  console.log(`Focused extraction complete: ${allCharacters.length} total characters`);
  return allCharacters;
}

function getVerifiedCharacters() {
  return [
    { name: "ALEX", image: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", className: "Fairy Berserker", level: 30, source: "verified" },
    { name: "Lady Rangiku (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", className: "Blade Healer", level: 40, source: "verified" },
    { name: "The Fork Knight (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", className: "Time Traveler", level: 52, source: "verified" },
    { name: "INSPIRED", image: "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png", className: "El Shooter", level: 11, source: "verified" }
  ];
}

async function incrementalDiscovery() {
  console.log('Running incremental discovery around known patterns...');
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Extract patterns from known working URLs
  const knownAssets = [
    { id: '2V3dKNSD41QjeLowfolcG3', hash: 'e9a4eb087190d640b9c6c982a17480d4', file: 'image.png' },
    { id: '3AYkauQlVdSQfVvdWtmaT', hash: '895be1409a709d60553bb820c213d45f', file: 'Rangiku.jpg' },
    { id: '6NXglOf0VcEyW0X6W0umnp', hash: 'f6be1ff12713c114ecd0ba405a52c47f', file: 'Fork-JFSgen2.jpg' },
    { id: '1gmbAGrcfb0LJEhHP7YsNF', hash: '0892ed7d6ce14bc0ab30cb105981a55c', file: 'image.png' }
  ];
  
  let found = 0;
  
  // Method 1: Increment/decrement numbers in asset IDs
  for (const asset of knownAssets) {
    const numbers = asset.id.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        const numVal = parseInt(num);
        
        // Test increments
        for (let delta = 1; delta <= 50; delta++) {
          const newNum = numVal + delta;
          const newAssetId = asset.id.replace(num, newNum.toString());
          
          const testUrl = `https://images.ctfassets.net/${spaceId}/${newAssetId}/${asset.hash}/${asset.file}`;
          
          try {
            const isValid = await testImageUrl(testUrl);
            if (isValid) {
              found++;
              console.log(`✓ Found increment [${found}]: ${testUrl}`);
              characters.push({
                name: `Knight Increment ${found}`,
                image: testUrl,
                source: 'incremental_discovery'
              });
            }
          } catch (error) {
            continue;
          }
        }
        
        // Test decrements
        for (let delta = 1; delta <= 20; delta++) {
          const newNum = numVal - delta;
          if (newNum > 0) {
            const newAssetId = asset.id.replace(num, newNum.toString());
            
            const testUrl = `https://images.ctfassets.net/${spaceId}/${newAssetId}/${asset.hash}/${asset.file}`;
            
            try {
              const isValid = await testImageUrl(testUrl);
              if (isValid) {
                found++;
                console.log(`✓ Found decrement [${found}]: ${testUrl}`);
                characters.push({
                  name: `Knight Decrement ${found}`,
                  image: testUrl,
                  source: 'incremental_discovery'
                });
              }
            } catch (error) {
              continue;
            }
          }
        }
      }
    }
  }
  
  // Method 2: Test with different file extensions for same assets
  const fileVariations = ['image.png', 'image.jpg', 'knight.png', 'knight.jpg', 'character.png', 'avatar.jpg', 'profile.png'];
  
  for (const asset of knownAssets) {
    for (const fileName of fileVariations) {
      if (fileName !== asset.file) { // Skip the already known combination
        const testUrl = `https://images.ctfassets.net/${spaceId}/${asset.id}/${asset.hash}/${fileName}`;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Found file variation [${found}]: ${testUrl}`);
            characters.push({
              name: `Knight File Variation ${found}`,
              image: testUrl,
              source: 'file_variation'
            });
          }
        } catch (error) {
          continue;
        }
      }
    }
  }
  
  // Method 3: Test hash variations systematically
  for (const asset of knownAssets) {
    const baseHash = asset.hash;
    
    // Modify last byte systematically
    for (let i = 0; i < 256; i++) {
      const lastByte = i.toString(16).padStart(2, '0');
      const newHash = baseHash.substring(0, 30) + lastByte;
      
      const testUrl = `https://images.ctfassets.net/${spaceId}/${asset.id}/${newHash}/${asset.file}`;
      
      try {
        const isValid = await testImageUrl(testUrl);
        if (isValid) {
          found++;
          console.log(`✓ Found hash variation [${found}]: ${testUrl}`);
          characters.push({
            name: `Knight Hash Variation ${found}`,
            image: testUrl,
            source: 'hash_variation'
          });
        }
      } catch (error) {
        continue;
      }
      
      // Limit hash testing to prevent excessive requests
      if (i > 50) break;
    }
  }
  
  console.log(`Incremental discovery complete: ${found} new characters found`);
  return characters;
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; ImageBot/1.0)'
      },
      timeout: 500
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Get all Knights characters from manual data and add discovered image URLs
export async function getAllKnightsWithDiscoveredImages() {
  console.log('Loading all Knights characters and discovering images...');
  
  const { knightsData } = await import('./knights-manual-extracted.js');
  const allCharacters = [];
  
  // Add characters with verified images
  const verifiedCharacters = knightsData.filter(knight => 
    knight.avatarUrl && 
    knight.avatarUrl.includes('ctfassets.net') && 
    !knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')
  );
  
  for (const knight of verifiedCharacters) {
    allCharacters.push({
      name: knight.name,
      playerName: knight.playerName,
      className: knight.className,
      level: knight.level,
      image: knight.avatarUrl,
      notes: knight.notes,
      strength: knight.strength,
      constitution: knight.constitution,
      dexterity: knight.dexterity,
      luck: knight.luck,
      customStats: knight.customStats,
      source: 'manual_verified'
    });
  }
  
  // Discover additional images using focused extraction
  const discoveredCharacters = await extractAllKnightsFocused();
  const existingUrls = new Set(allCharacters.map(char => char.image));
  
  for (const char of discoveredCharacters) {
    if (!existingUrls.has(char.image)) {
      allCharacters.push(char);
      existingUrls.add(char.image);
    }
  }
  
  console.log(`Total Knights characters: ${allCharacters.length}`);
  return allCharacters;
}