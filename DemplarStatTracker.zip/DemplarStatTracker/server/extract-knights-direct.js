// Direct Knights character image extraction using fetch and DOM parsing
import https from 'https';

// Extract image URLs from Knights website HTML
export async function extractKnightsFromHTML() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'knightsofdegen.netlify.app',
      port: 443,
      path: '/',
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        // Extract Contentful asset references from the HTML/JS
        const assetMatches = data.match(/b474hutgbdbv\/[0-9a-zA-Z]{22}\/[0-9a-f]{32}\/[^"'\s<>]+\.(jpg|png|jpeg)/g) || [];
        const uniqueAssets = [...new Set(assetMatches)];
        
        const fullUrls = uniqueAssets.map(asset => `https://images.ctfassets.net/${asset}`);
        resolve(fullUrls);
      });
    });

    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    
    req.end();
  });
}

// Test and validate discovered URLs
export async function validateExtractedUrls(urls) {
  const validUrls = [];
  
  for (const url of urls) {
    try {
      const isValid = await testUrl(url);
      if (isValid) {
        validUrls.push(url);
        console.log(`✓ Validated: ${url}`);
      }
    } catch (error) {
      console.log(`✗ Invalid: ${url}`);
    }
  }
  
  return validUrls;
}

function testUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      resolve(res.statusCode === 200);
    }).on('error', () => resolve(false));
  });
}

// Main extraction function
export async function discoverKnightsImages() {
  console.log('Extracting Knights character images from website...');
  
  try {
    const extractedUrls = await extractKnightsFromHTML();
    console.log(`Found ${extractedUrls.length} potential image URLs`);
    
    const validUrls = await validateExtractedUrls(extractedUrls);
    console.log(`Validated ${validUrls.length} working image URLs`);
    
    return validUrls;
  } catch (error) {
    console.error('Extraction error:', error);
    return [];
  }
}

// Update Knights data with discovered URLs
export async function autoUpdateKnightsData() {
  const discoveredUrls = await discoverKnightsImages();
  
  if (discoveredUrls.length > 4) {
    console.log(`Updating Knights with ${discoveredUrls.length} discovered URLs...`);
    
    // Known character mappings based on filename patterns
    const characterMappings = {
      'Certified_Lover_Bull': 'CERTIFIEDLOVERBULL',
      'Tommy': 'Tommy',
      'True_Warrior': 'True Warrior',
      'DENOJAH': 'DENOJAH',
      'Sir_Nemo': 'Sir Nemo [AI]',
      'MDK': 'MDK',
      'American_Hearts': 'American Hearts',
      'Chair': 'Chair',
      'JEST': 'JEST',
      'Meggy': 'Meggy',
      'Wicked': 'W!¢KغD',
      'Ponderer': 'Ponderer',
      '2NA': '2NA',
      'BloodE': '🩸Ǝ',
      'Yoss0x': 'Yoss0x',
      'Sizzler': 'Sizzler',
      'MCO_Wolf': 'MCO WOLF (λ2)',
      'IFiHAD': 'IFiHAD'
    };
    
    const mappedUrls = {};
    
    for (const url of discoveredUrls) {
      for (const [filename, characterName] of Object.entries(characterMappings)) {
        if (url.includes(filename)) {
          mappedUrls[characterName] = url;
          break;
        }
      }
    }
    
    return { success: true, mappedUrls, totalUrls: discoveredUrls.length };
  }
  
  return { success: false, mappedUrls: {}, totalUrls: discoveredUrls.length };
}