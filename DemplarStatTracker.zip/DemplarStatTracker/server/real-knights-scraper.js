// Real Knights character image scraper - extracts actual URLs from knightsofdegen.netlify.app
import puppeteer from 'puppeteer';

export async function scrapeKnightsFromWebsite() {
  console.log('Starting real Knights character scraping from knightsofdegen.netlify.app...');
  
  let browser;
  const scrapedCharacters = [];
  
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
        '--disable-gpu'
      ]
    });
    
    const page = await browser.newPage();
    
    // Set a realistic user agent
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    
    console.log('Navigating to Knights website...');
    await page.goto('https://knightsofdegen.netlify.app/', { 
      waitUntil: 'networkidle2',
      timeout: 30000 
    });
    
    // Wait for React app to load and character cards to appear
    console.log('Waiting for character cards to load...');
    await page.waitForTimeout(5000);
    
    // Try multiple selectors to find character cards
    const cardSelectors = [
      '.character-card',
      '.card',
      '[class*="card"]',
      '[class*="character"]',
      '.knight-card',
      'div[role="button"]',
      'button',
      'a[href*="character"]'
    ];
    
    let characterCards = [];
    for (const selector of cardSelectors) {
      try {
        characterCards = await page.$$(selector);
        if (characterCards.length > 0) {
          console.log(`Found ${characterCards.length} character cards using selector: ${selector}`);
          break;
        }
      } catch (e) {
        continue;
      }
    }
    
    if (characterCards.length === 0) {
      console.log('No character cards found, trying to extract from page source...');
      
      // Extract any Contentful image URLs from the page source
      const contentfulUrls = await page.evaluate(() => {
        const pageContent = document.documentElement.innerHTML;
        const urlRegex = /https:\/\/images\.ctfassets\.net\/[^"'\s]+/g;
        return pageContent.match(urlRegex) || [];
      });
      
      if (contentfulUrls.length > 0) {
        console.log(`Found ${contentfulUrls.length} Contentful URLs in page source`);
        contentfulUrls.forEach((url, index) => {
          scrapedCharacters.push({
            name: `Knight #${index + 1}`,
            image: url,
            source: 'page_source'
          });
        });
      }
      
      return scrapedCharacters;
    }
    
    // Process each character card
    const maxCards = Math.min(characterCards.length, 20); // Limit to avoid timeout
    
    for (let i = 0; i < maxCards; i++) {
      try {
        console.log(`Processing character card ${i + 1}/${maxCards}...`);
        
        // Get a fresh reference to the card
        const cards = await page.$$(cardSelectors.find(s => s));
        if (!cards[i]) continue;
        
        // Try to extract character name before clicking
        const characterName = await cards[i].evaluate(el => {
          return el.textContent?.trim() || el.getAttribute('alt') || el.getAttribute('title') || `Knight #${Date.now()}`;
        });
        
        // Click the character card
        await cards[i].click();
        await page.waitForTimeout(2000);
        
        // Look for modal, popup, or new content
        const modalSelectors = [
          '.modal img',
          '.popup img', 
          '[class*="modal"] img',
          '[class*="popup"] img',
          'img[src*="ctfassets"]',
          'img[src*="cdn"]'
        ];
        
        let imageUrl = null;
        
        for (const selector of modalSelectors) {
          try {
            const imgElement = await page.$(selector);
            if (imgElement) {
              imageUrl = await imgElement.evaluate(img => img.src);
              if (imageUrl && imageUrl.includes('ctfassets')) {
                console.log(`✓ Found image URL for ${characterName}: ${imageUrl}`);
                break;
              }
            }
          } catch (e) {
            continue;
          }
        }
        
        // Look for "open in new tab" links
        if (!imageUrl) {
          const linkSelectors = [
            'a[href*="ctfassets"]',
            'a[target="_blank"]',
            '[href*="image"]',
            'a[href*="cdn"]'
          ];
          
          for (const selector of linkSelectors) {
            try {
              const linkElement = await page.$(selector);
              if (linkElement) {
                imageUrl = await linkElement.evaluate(link => link.href);
                if (imageUrl && imageUrl.includes('ctfassets')) {
                  console.log(`✓ Found image URL via link for ${characterName}: ${imageUrl}`);
                  break;
                }
              }
            } catch (e) {
              continue;
            }
          }
        }
        
        if (imageUrl) {
          scrapedCharacters.push({
            name: characterName,
            image: imageUrl,
            source: 'character_card'
          });
        }
        
        // Close modal by pressing Escape or clicking outside
        await page.keyboard.press('Escape');
        await page.waitForTimeout(1000);
        
      } catch (error) {
        console.log(`Error processing card ${i + 1}: ${error.message}`);
        continue;
      }
    }
    
  } catch (error) {
    console.error('Scraping error:', error);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
  
  console.log(`Scraping complete. Found ${scrapedCharacters.length} character images.`);
  return scrapedCharacters;
}

// Alternative approach using fetch and HTML parsing
export async function extractFromPageSource() {
  console.log('Extracting Knights URLs from page source...');
  
  try {
    const response = await fetch('https://knightsofdegen.netlify.app/', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const html = await response.text();
    
    // Extract all Contentful image URLs
    const contentfulRegex = /https:\/\/images\.ctfassets\.net\/[^"'\s<>]+\.(jpg|png|jpeg|gif)/gi;
    const urls = html.match(contentfulRegex) || [];
    
    const uniqueUrls = [...new Set(urls)];
    console.log(`Found ${uniqueUrls.length} unique image URLs in page source`);
    
    return uniqueUrls.map((url, index) => ({
      name: `Knight #${index + 1}`,
      image: url,
      source: 'html_source'
    }));
    
  } catch (error) {
    console.error('Page source extraction error:', error);
    return [];
  }
}