// Optimized Knights character extraction focusing on efficient discovery
import https from 'https';

export async function extractAllKnightsOptimized() {
  console.log('Starting optimized Knights character extraction...');
  
  const allCharacters = [];
  const foundUrls = new Set();
  
  // Add verified characters first
  const verifiedCharacters = getVerifiedCharacters();
  for (const char of verifiedCharacters) {
    allCharacters.push(char);
    foundUrls.add(char.image);
  }
  
  // Run targeted discovery methods
  const discoveredCharacters = await runTargetedDiscovery();
  
  for (const char of discoveredCharacters) {
    if (!foundUrls.has(char.image)) {
      allCharacters.push(char);
      foundUrls.add(char.image);
    }
  }
  
  console.log(`Optimized extraction complete: ${allCharacters.length} total characters`);
  return allCharacters;
}

function getVerifiedCharacters() {
  return [
    { name: "ALEX", image: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", className: "Fairy Berserker", level: 30, source: "verified" },
    { name: "Lady Rangiku (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", className: "Blade Healer", level: 40, source: "verified" },
    { name: "The Fork Knight (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", className: "Time Traveler", level: 52, source: "verified" },
    { name: "INSPIRED", image: "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png", className: "El Shooter", level: 11, source: "verified" }
  ];
}

async function runTargetedDiscovery() {
  console.log('Running targeted discovery...');
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Focus on most promising asset ID patterns based on verified data
  const targetAssetIds = generateTargetAssetIds();
  const targetHashes = generateTargetHashes();
  const fileNames = ['image.png', 'image.jpg', 'knight.jpg', 'character.png', 'avatar.jpg'];
  
  console.log(`Testing ${targetAssetIds.length} targeted asset IDs...`);
  
  let tested = 0;
  let found = 0;
  
  for (const assetId of targetAssetIds.slice(0, 100)) { // Limit to top 100 most promising
    for (const hash of targetHashes.slice(0, 3)) { // Top 3 hash patterns per asset
      for (const fileName of fileNames) {
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Found [${found}]: ${testUrl}`);
            characters.push({
              name: `Knight Discovery ${found}`,
              image: testUrl,
              source: 'targeted_discovery'
            });
          }
        } catch (error) {
          continue;
        }
        
        // Progress update every 100 tests
        if (tested % 100 === 0) {
          console.log(`Progress: ${tested} tested, ${found} found`);
          await new Promise(resolve => setTimeout(resolve, 50));
        }
      }
    }
  }
  
  console.log(`Targeted discovery complete: ${tested} URLs tested, ${found} characters found`);
  return characters;
}

function generateTargetAssetIds() {
  const assetIds = [];
  
  // Known working patterns
  const knownIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT', 
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  // Add variations of known IDs (most promising)
  for (const baseId of knownIds) {
    // Increment numbers in the ID
    const numbers = baseId.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        const numVal = parseInt(num);
        for (let delta = -20; delta <= 20; delta++) {
          if (delta !== 0) {
            const newNum = numVal + delta;
            if (newNum > 0) {
              const newId = baseId.replace(num, newNum.toString());
              assetIds.push(newId);
            }
          }
        }
      }
    }
    
    // Character substitutions at strategic positions
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    
    // Focus on last few characters (most likely to vary)
    for (let pos = baseId.length - 3; pos < baseId.length; pos++) {
      for (const char of chars) {
        const newId = baseId.substring(0, pos) + char + baseId.substring(pos + 1);
        assetIds.push(newId);
      }
    }
    
    // Focus on positions after numbers (common pattern)
    for (let i = 0; i < baseId.length - 1; i++) {
      if (/\d/.test(baseId[i])) {
        for (const char of chars.slice(0, 20)) { // Test top 20 chars
          const newId = baseId.substring(0, i + 1) + char + baseId.substring(i + 2);
          assetIds.push(newId);
        }
      }
    }
  }
  
  // Generate new IDs based on observed patterns
  const prefixes = ['1', '2', '3', '4', '5', '6', '7'];
  const midPatterns = ['gmb', 'V3d', 'AYk', 'Xgl'];
  const suffixes = ['G3', 'NF', 'nP', 'aT'];
  
  for (const prefix of prefixes) {
    for (const midPattern of midPatterns) {
      for (const suffix of suffixes) {
        // Fill in random chars for remaining positions
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (let i = 0; i < 5; i++) {
          let assetId = prefix + midPattern;
          
          // Add random chars to reach appropriate length (22 chars total)
          const remainingLength = 22 - assetId.length - suffix.length;
          for (let j = 0; j < remainingLength; j++) {
            assetId += chars[Math.floor(Math.random() * chars.length)];
          }
          assetId += suffix;
          
          assetIds.push(assetId);
        }
      }
    }
  }
  
  // Remove duplicates and return
  return [...new Set(assetIds)];
}

function generateTargetHashes() {
  const hashes = [];
  
  // Known working hashes
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  hashes.push(...knownHashes);
  
  // Generate variations by modifying last bytes (most efficient approach)
  const hexChars = '0123456789abcdef';
  
  for (const baseHash of knownHashes) {
    // Modify last 2 characters (most promising variations)
    for (let i = 0; i < 256; i++) {
      const lastByte = i.toString(16).padStart(2, '0');
      const newHash = baseHash.substring(0, 30) + lastByte;
      hashes.push(newHash);
    }
    
    // Modify middle section systematically
    for (let i = 0; i < 16; i++) {
      for (let j = 0; j < 16; j++) {
        const newHash = baseHash.substring(0, 16) + hexChars[i] + hexChars[j] + baseHash.substring(18);
        hashes.push(newHash);
      }
    }
  }
  
  return [...new Set(hashes)];
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; ImageBot/1.0)'
      },
      timeout: 800
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Quick test to verify extraction works
export async function quickTestExtraction() {
  console.log('Running quick extraction test...');
  
  const characters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Test a few promising patterns quickly
  const testAssetIds = [
    '2V3dKNSD41QjeLowfolcG4', // Known ID + 1
    '3AYkauQlVdSQfVvdWtmaT1', // Known ID + variation
    '1gmbAGrcfb0LJEhHP7YsNG'  // Known ID + variation
  ];
  
  const testHash = 'e9a4eb087190d640b9c6c982a17480d4'; // Known working hash
  const testFiles = ['image.png', 'image.jpg'];
  
  for (const assetId of testAssetIds) {
    for (const fileName of testFiles) {
      const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${testHash}/${fileName}`;
      
      try {
        const isValid = await testImageUrl(testUrl);
        if (isValid) {
          console.log(`✓ Quick test found: ${testUrl}`);
          characters.push({
            name: `Quick Test Character ${characters.length + 1}`,
            image: testUrl,
            source: 'quick_test'
          });
        }
      } catch (error) {
        continue;
      }
    }
  }
  
  console.log(`Quick test complete: ${characters.length} characters found`);
  return characters;
}