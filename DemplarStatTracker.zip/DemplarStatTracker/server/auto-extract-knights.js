// Comprehensive Knights character image URL discovery system
import https from 'https';
import { writeFileSync } from 'fs';

// Test if a URL returns a valid image
function testUrl(url) {
  return new Promise((resolve) => {
    const request = https.request(url, { method: 'HEAD' }, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type']?.startsWith('image/');
      resolve(isValid);
    });
    
    request.on('error', () => resolve(false));
    request.setTimeout(5000, () => {
      request.destroy();
      resolve(false);
    });
    
    request.end();
  });
}

// Generate asset ID variations based on Contentful patterns
function generateAssetIdVariations() {
  const basePatterns = [
    '1gmbAGrcfb0LJEhHP7YsNF',
    '2V3dKNSD41QjeLowfolcG3', 
    '3AYkauQlVdSQfVvdWtmaT',
    '6NXglOf0VcEyW0X6W0umnp'
  ];
  
  const variations = [];
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  
  // Generate systematic variations
  for (let i = 0; i < 200; i++) {
    const basePattern = basePatterns[i % basePatterns.length];
    let assetId = '';
    
    // Create variations by changing 1-3 characters
    for (let j = 0; j < 22; j++) {
      if (Math.random() < 0.85) {
        assetId += basePattern[j];
      } else {
        assetId += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    
    variations.push(assetId);
  }
  
  // Add sequential patterns
  const prefixes = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c'];
  const suffixes = ['gmbAGrcfb0LJEhHP7YsNF', 'V3dKNSD41QjeLowfolcG3', 'AYkauQlVdSQfVvdWtmaT'];
  
  for (const prefix of prefixes) {
    for (const suffix of suffixes) {
      variations.push(prefix + suffix);
    }
  }
  
  return [...new Set(variations)];
}

// Generate hash variations
function generateHashVariations() {
  const baseHashes = [
    '0892ed7d6ce14bc0ab30cb105981a55c',
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f'
  ];
  
  const variations = [];
  const hexChars = '0123456789abcdef';
  
  // Generate hash variations
  for (let i = 0; i < 100; i++) {
    const baseHash = baseHashes[i % baseHashes.length];
    let hash = '';
    
    for (let j = 0; j < 32; j++) {
      if (Math.random() < 0.9) {
        hash += baseHash[j];
      } else {
        hash += hexChars[Math.floor(Math.random() * hexChars.length)];
      }
    }
    
    variations.push(hash);
  }
  
  return [...new Set(variations)];
}

// Discover all Knights URLs systematically
export async function discoverAllKnightsUrls() {
  console.log('Starting comprehensive Knights character image discovery...');
  
  const assetIds = generateAssetIdVariations();
  const hashes = generateHashVariations();
  const filenames = [
    'image.png', 'image.jpg', 'character.png', 'avatar.jpg',
    'Rangiku.jpg', 'Fork-JFSgen2.jpg', 'Tommy.png', 'MDK.jpg',
    'Chair.png', 'JEST.jpg', 'Meggy.png', 'Wicked.jpg'
  ];
  
  const workingUrls = [];
  let testCount = 0;
  const maxTests = 500;
  
  console.log(`Testing up to ${maxTests} URL combinations...`);
  
  // Test combinations systematically
  for (let i = 0; i < assetIds.length && testCount < maxTests; i++) {
    for (let j = 0; j < hashes.length && testCount < maxTests; j++) {
      for (let k = 0; k < filenames.length && testCount < maxTests; k++) {
        const url = `https://images.ctfassets.net/b474hutgbdbv/${assetIds[i]}/${hashes[j]}/${filenames[k]}`;
        
        testCount++;
        console.log(`Testing ${testCount}/${maxTests}: ${url.substring(0, 80)}...`);
        
        const isValid = await testUrl(url);
        if (isValid) {
          workingUrls.push(url);
          console.log(`✓ FOUND WORKING URL: ${url}`);
        }
        
        // Small delay to be respectful
        if (testCount % 10 === 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
  }
  
  console.log(`Discovery complete: ${testCount} URLs tested, ${workingUrls.length} working URLs found`);
  return workingUrls;
}

// Update Knights data file with discovered URLs
export async function autoUpdateKnightsFile() {
  const discoveredUrls = await discoverAllKnightsUrls();
  
  if (discoveredUrls.length > 4) {
    console.log('Updating Knights character file with discovered URLs...');
    
    // Create updated Knights data
    const updatedKnightsData = `// Auto-generated Knights character data with discovered image URLs
export const knightsData = [
  // Verified working URLs
${discoveredUrls.map((url, index) => `  {
    name: "Knight_${index + 1}",
    className: "Unknown", 
    level: 1,
    location: "Unknown",
    avatarUrl: "${url}",
    cardBuff: "+5% to all stats (Knights of Degen member)"
  }`).join(',\n')}
];`;
    
    writeFileSync('./knights-discovered.js', updatedKnightsData);
    console.log(`Created knights-discovered.js with ${discoveredUrls.length} working URLs`);
    
    return { success: true, urlCount: discoveredUrls.length, urls: discoveredUrls };
  }
  
  return { success: false, urlCount: discoveredUrls.length, urls: discoveredUrls };
}