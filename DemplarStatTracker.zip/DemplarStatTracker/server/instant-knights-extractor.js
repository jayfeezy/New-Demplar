// Instant Knights character extraction - immediate results
export async function getAllKnightsInstant() {
  console.log('Loading all Knights characters instantly...');
  
  const { knightsData } = await import('./knights-manual-extracted.js');
  const allCharacters = [];
  
  // Process all Knights characters from the comprehensive manual data
  for (const knight of knightsData) {
    const character = {
      name: knight.name,
      playerName: knight.playerName,
      className: knight.className,
      level: knight.level,
      notes: knight.notes,
      strength: knight.strength || 55,
      constitution: knight.constitution || 55,
      dexterity: knight.dexterity || 55,
      luck: knight.luck || 55,
      customStats: knight.customStats || { "Critical": 55, "Magic Defense": 55 },
      source: 'knights_of_degen_data'
    };
    
    // Add verified image URL if available
    if (knight.avatarUrl && knight.avatarUrl.includes('ctfassets.net') && !knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')) {
      character.image = knight.avatarUrl;
      character.source = 'verified_image';
    }
    
    allCharacters.push(character);
  }
  
  const withImages = allCharacters.filter(char => char.image).length;
  const withoutImages = allCharacters.length - withImages;
  
  console.log(`Instant extraction complete: ${allCharacters.length} total Knights characters`);
  console.log(`- ${withImages} with verified images from knightsofdegen.netlify.app`);
  console.log(`- ${withoutImages} character data without images`);
  
  return allCharacters;
}

// Get summary of all Knights characters
export function getKnightsSummary(characters) {
  const summary = {
    total: characters.length,
    withImages: characters.filter(char => char.image).length,
    withoutImages: characters.filter(char => !char.image).length,
    classes: {},
    levels: {},
    locations: {}
  };
  
  // Analyze character classes
  characters.forEach(char => {
    if (char.className) {
      summary.classes[char.className] = (summary.classes[char.className] || 0) + 1;
    }
    
    // Extract level ranges
    const levelRange = Math.floor(char.level / 10) * 10;
    const rangeKey = `${levelRange}-${levelRange + 9}`;
    summary.levels[rangeKey] = (summary.levels[rangeKey] || 0) + 1;
    
    // Extract locations from notes
    if (char.notes && char.notes.includes('Location:')) {
      const locationMatch = char.notes.match(/Location:\s*([^\n]+)/);
      if (locationMatch) {
        const location = locationMatch[1].trim();
        summary.locations[location] = (summary.locations[location] || 0) + 1;
      }
    }
  });
  
  return summary;
}