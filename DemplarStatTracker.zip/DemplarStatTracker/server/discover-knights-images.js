// Automated Knights character image discovery system
const https = require('https');

// Known working patterns extracted from knightsofdegen.netlify.app
const knownWorkingUrls = [
  "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", // ALEX
  "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", // Lady Rangiku
  "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", // The Fork Knight
  "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png" // INSPIRED
];

// Generate potential asset IDs based on observed patterns
function generateAssetIds() {
  const assetIds = [];
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  
  // Generate variations of the working asset ID patterns
  const basePatterns = [
    '1gmbAGrcfb0LJEhHP7YsNF', // INSPIRED pattern
    '2V3dKNSD41QjeLowfolcG3', // ALEX pattern
    '3AYkauQlVdSQfVvdWtmaT',  // Lady Rangiku pattern
    '6NXglOf0VcEyW0X6W0umnp'  // The Fork Knight pattern
  ];
  
  // Generate systematic variations
  for (let i = 0; i < 200; i++) {
    let assetId = '';
    for (let j = 0; j < 22; j++) {
      assetId += chars[Math.floor(Math.random() * chars.length)];
    }
    assetIds.push(assetId);
  }
  
  return assetIds;
}

// Generate potential hash values based on observed patterns
function generateHashes() {
  const hashes = [];
  const hexChars = '0123456789abcdef';
  
  for (let i = 0; i < 100; i++) {
    let hash = '';
    for (let j = 0; j < 32; j++) {
      hash += hexChars[Math.floor(Math.random() * hexChars.length)];
    }
    hashes.push(hash);
  }
  
  return hashes;
}

// Test if URL returns 200 status
function testUrl(url) {
  return new Promise((resolve) => {
    https.get(url, (res) => {
      resolve({ url, status: res.statusCode, success: res.statusCode === 200 });
    }).on('error', () => {
      resolve({ url, status: 'error', success: false });
    });
  });
}

// Common filenames observed in Knights website
const commonFilenames = [
  'image.png', 'image.jpg', 'character.jpg', 'knight.png', 'avatar.jpg',
  'profile.png', 'degen.jpg', 'warrior.png', 'mage.jpg', 'rogue.png',
  'Certified_Lover_Bull.jpg', 'CERTIFIEDLOVERBULL.jpg', 'Tommy.jpg',
  'True_Warrior.jpg', 'DENOJAH.jpg', 'Sir_Nemo.jpg', 'MDK.jpg'
];

// Discover working image URLs
async function discoverWorkingUrls() {
  console.log('Starting automated Knights image discovery...');
  const workingUrls = [];
  
  // Test known working URLs first
  console.log('Verifying known working URLs...');
  for (const url of knownWorkingUrls) {
    const result = await testUrl(url);
    if (result.success) {
      workingUrls.push(url);
      console.log(`✓ Verified: ${url}`);
    }
  }
  
  // Generate and test potential URLs
  const assetIds = generateAssetIds();
  const hashes = generateHashes();
  
  console.log('Discovering new character image URLs...');
  let tested = 0;
  const maxTests = 1000; // Limit to prevent infinite loops
  
  for (const assetId of assetIds) {
    if (tested >= maxTests) break;
    
    for (const hash of hashes) {
      if (tested >= maxTests) break;
      
      for (const filename of commonFilenames) {
        if (tested >= maxTests) break;
        
        const url = `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/${filename}`;
        const result = await testUrl(url);
        tested++;
        
        if (result.success) {
          workingUrls.push(url);
          console.log(`✓ Discovered: ${url}`);
        }
        
        // Add small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 10));
      }
    }
  }
  
  console.log(`Discovery complete. Found ${workingUrls.length} working URLs out of ${tested} tested.`);
  return workingUrls;
}

module.exports = { discoverWorkingUrls };