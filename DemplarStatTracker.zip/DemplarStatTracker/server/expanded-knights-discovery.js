// Expanded Knights discovery using broader asset ID patterns and content analysis
import https from 'https';

export async function discoverAllKnightsExpanded() {
  console.log('Starting expanded Knights character discovery...');
  
  const allCharacters = [];
  const spaceId = 'b474hutgbdbv';
  
  // Add verified characters
  const verifiedCharacters = await getVerifiedCharacters();
  allCharacters.push(...verifiedCharacters);
  
  // Discover additional characters using expanded patterns
  const discoveredCharacters = await expandedAssetDiscovery(spaceId);
  
  // Merge without duplicates
  const existingUrls = new Set(allCharacters.map(char => char.image));
  for (const char of discoveredCharacters) {
    if (!existingUrls.has(char.image)) {
      allCharacters.push(char);
      existingUrls.add(char.image);
    }
  }
  
  console.log(`Total unique Knights discovered: ${allCharacters.length}`);
  return allCharacters;
}

async function getVerifiedCharacters() {
  return [
    { name: "ALEX", image: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png", className: "Fairy Berserker", level: 30, source: "verified" },
    { name: "Lady Rangiku (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg", className: "Blade Healer", level: 40, source: "verified" },
    { name: "The Fork Knight (λ2)", image: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg", className: "Time Traveler", level: 52, source: "verified" },
    { name: "INSPIRED", image: "https://images.ctfassets.net/b474hutgbdbv/1gmbAGrcfb0LJEhHP7YsNF/0892ed7d6ce14bc0ab30cb105981a55c/image.png", className: "El Shooter", level: 11, source: "verified" }
  ];
}

async function expandedAssetDiscovery(spaceId) {
  const discoveredCharacters = [];
  
  // Generate comprehensive asset ID patterns
  const assetPatterns = generateAssetPatterns();
  const hashPatterns = generateHashPatterns();
  const filePatterns = ['image.png', 'image.jpg', 'knight.png', 'knight.jpg', 'character.png', 'avatar.jpg'];
  
  console.log(`Testing ${assetPatterns.length} asset patterns...`);
  
  let tested = 0;
  const maxTests = 500;
  
  for (let i = 0; i < assetPatterns.length && tested < maxTests; i++) {
    const assetId = assetPatterns[i];
    
    for (let j = 0; j < Math.min(hashPatterns.length, 5) && tested < maxTests; j++) {
      const hash = hashPatterns[j];
      
      for (const fileName of filePatterns) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            console.log(`✓ Discovered: ${testUrl}`);
            discoveredCharacters.push({
              name: `Knight ${discoveredCharacters.length + 1}`,
              image: testUrl,
              source: 'expanded_discovery'
            });
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 50 === 0) {
          console.log(`Progress: ${tested}/${maxTests} tested, ${discoveredCharacters.length} found`);
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
    }
  }
  
  console.log(`Expanded discovery complete: ${tested} URLs tested, ${discoveredCharacters.length} new characters found`);
  return discoveredCharacters;
}

function generateAssetPatterns() {
  const patterns = [];
  
  // Known working patterns as base
  const knownAssetIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT',
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  patterns.push(...knownAssetIds);
  
  // Generate systematic variations
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  
  // Pattern 1: Similar length and structure to known IDs (22 characters)
  for (let i = 0; i < 50; i++) {
    let pattern = '';
    
    // First character (digit or letter)
    pattern += Math.random() > 0.5 ? Math.floor(Math.random() * 10) : chars[Math.floor(Math.random() * 26)];
    
    // Mix of letters and numbers for middle part
    for (let j = 1; j < 22; j++) {
      if (j === 7 || j === 14) {
        // Insert common delimiters at certain positions
        pattern += chars[Math.floor(Math.random() * 52)]; // Letters only
      } else {
        pattern += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    
    patterns.push(pattern);
  }
  
  // Pattern 2: Variations on known successful IDs
  for (const knownId of knownAssetIds) {
    // Increment/decrement numbers in the ID
    const numbers = knownId.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        const numVal = parseInt(num);
        for (let delta = -5; delta <= 5; delta++) {
          if (delta !== 0) {
            const newNum = numVal + delta;
            if (newNum > 0) {
              const newId = knownId.replace(num, newNum.toString());
              patterns.push(newId);
            }
          }
        }
      }
    }
    
    // Character substitutions
    for (let pos = 0; pos < knownId.length; pos++) {
      for (let c = 0; c < 10; c++) {
        const newId = knownId.substring(0, pos) + chars[c] + knownId.substring(pos + 1);
        patterns.push(newId);
      }
    }
  }
  
  // Remove duplicates
  return [...new Set(patterns)];
}

function generateHashPatterns() {
  const patterns = [];
  
  // Known working hashes
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  patterns.push(...knownHashes);
  
  // Generate hash variations
  const hexChars = '0123456789abcdef';
  
  for (const hash of knownHashes) {
    // Modify last 4 characters
    for (let i = 0; i < 20; i++) {
      let newHash = hash.substring(0, hash.length - 4);
      for (let j = 0; j < 4; j++) {
        newHash += hexChars[Math.floor(Math.random() * 16)];
      }
      patterns.push(newHash);
    }
    
    // Modify middle section
    for (let i = 0; i < 10; i++) {
      let newHash = hash.substring(0, 16);
      for (let j = 16; j < 24; j++) {
        newHash += hexChars[Math.floor(Math.random() * 16)];
      }
      newHash += hash.substring(24);
      patterns.push(newHash);
    }
  }
  
  // Generate completely new hash patterns based on common structures
  for (let i = 0; i < 30; i++) {
    let hash = '';
    for (let j = 0; j < 32; j++) {
      hash += hexChars[Math.floor(Math.random() * 16)];
    }
    patterns.push(hash);
  }
  
  return [...new Set(patterns)];
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; KnightsBot/1.0)'
      },
      timeout: 1500
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

// Alternative approach: try to find patterns in Contentful's asset naming
export async function analyzeContentfulPatterns() {
  console.log('Analyzing Contentful asset patterns...');
  
  const results = [];
  
  // Test common Contentful asset ID patterns
  const commonPrefixes = ['1', '2', '3', '4', '5', '6', '7'];
  const commonSuffixes = ['G3', 'NF', 'nP', 'aT'];
  
  for (const prefix of commonPrefixes) {
    for (const suffix of commonSuffixes) {
      // Generate middle part
      const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      
      for (let i = 0; i < 5; i++) {
        let assetId = prefix;
        
        // Generate middle section (20 characters)
        for (let j = 0; j < 18; j++) {
          assetId += chars[Math.floor(Math.random() * chars.length)];
        }
        
        assetId += suffix;
        
        // Test with common hash pattern
        const testHash = 'a1b2c3d4e5f6789012345678901234ab';
        const testUrl = `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${testHash}/image.png`;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            results.push({
              name: `Pattern Knight ${results.length + 1}`,
              image: testUrl,
              source: 'pattern_analysis'
            });
          }
        } catch (error) {
          continue;
        }
      }
    }
  }
  
  return results;
}