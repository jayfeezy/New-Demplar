// Automated Knights character image extraction using Puppeteer
import puppeteer from 'puppeteer';
import fs from 'fs/promises';

export async function extractAllKnightsImages() {
  console.log('Starting automated Knights character image extraction...');
  
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  const page = await browser.newPage();
  const extractedUrls = [];
  
  try {
    // Navigate to Knights website
    console.log('Navigating to knightsofdegen.netlify.app...');
    await page.goto('https://knightsofdegen.netlify.app/', { 
      waitUntil: 'networkidle2',
      timeout: 30000
    });
    
    // Wait for character cards to load
    console.log('Waiting for character cards to load...');
    await page.waitForSelector('[class*="card"], [class*="character"], .card, .character-card', {
      timeout: 15000
    });
    
    // Get all character cards
    const characterCards = await page.$$('[class*="card"], [class*="character"], .card, .character-card');
    console.log(`Found ${characterCards.length} character cards`);
    
    for (let i = 0; i < characterCards.length && i < 50; i++) {
      try {
        console.log(`Processing character card ${i + 1}/${characterCards.length}`);
        
        // Click the character card
        await characterCards[i].click();
        
        // Wait for popup/modal to appear
        await page.waitForTimeout(2000);
        
        // Look for image or "open in new tab" button in top right
        const imageElements = await page.$$('img, [class*="image"], [href*="ctfassets"], [src*="ctfassets"]');
        
        for (const imageElement of imageElements) {
          try {
            const src = await imageElement.evaluate(el => el.src || el.href);
            if (src && src.includes('ctfassets.net') && src.includes('b474hutgbdbv')) {
              extractedUrls.push(src);
              console.log(`✓ Extracted: ${src}`);
            }
          } catch (e) {
            // Continue if element evaluation fails
          }
        }
        
        // Try to find and click "open in new tab" links
        const openInNewTabElements = await page.$$('[target="_blank"], [class*="new-tab"], [class*="external"]');
        
        for (const element of openInNewTabElements) {
          try {
            const href = await element.evaluate(el => el.href);
            if (href && href.includes('ctfassets.net')) {
              extractedUrls.push(href);
              console.log(`✓ Extracted from link: ${href}`);
            }
          } catch (e) {
            // Continue if element evaluation fails
          }
        }
        
        // Close modal/popup by pressing Escape or clicking outside
        await page.keyboard.press('Escape');
        await page.waitForTimeout(1000);
        
      } catch (error) {
        console.log(`Error processing card ${i + 1}: ${error.message}`);
        // Continue with next card
      }
    }
    
  } catch (error) {
    console.error('Error during extraction:', error);
  } finally {
    await browser.close();
  }
  
  // Remove duplicates
  const uniqueUrls = [...new Set(extractedUrls)];
  console.log(`Extraction complete. Found ${uniqueUrls.length} unique image URLs`);
  
  return uniqueUrls;
}

// Update Knights file with extracted URLs
export async function updateKnightsWithExtractedUrls() {
  const extractedUrls = await extractAllKnightsImages();
  
  if (extractedUrls.length > 0) {
    console.log('Updating Knights character file with extracted URLs...');
    
    // Read current Knights file
    const knightsFile = await fs.readFile('./knights-manual-extracted.js', 'utf8');
    
    let updatedFile = knightsFile;
    let urlIndex = 0;
    
    // Replace MANUAL_EXTRACT_NEEDED with real URLs
    while (updatedFile.includes('MANUAL_EXTRACT_NEEDED') && urlIndex < extractedUrls.length) {
      updatedFile = updatedFile.replace('MANUAL_EXTRACT_NEEDED', extractedUrls[urlIndex]);
      urlIndex++;
    }
    
    // Write updated file
    await fs.writeFile('./knights-manual-extracted.js', updatedFile);
    console.log(`Updated Knights file with ${urlIndex} authentic image URLs`);
    
    return { success: true, urlsAdded: urlIndex, totalUrls: extractedUrls.length };
  }
  
  return { success: false, urlsAdded: 0, totalUrls: 0 };
}