// Knights API discovery - find the real backend endpoints
import https from 'https';
import { URL } from 'url';

export async function discoverKnightsAPI() {
  console.log('Starting Knights API discovery...');
  
  const potentialEndpoints = [
    // Common API patterns
    'https://api.knightsofdegen.com/characters',
    'https://api.knightsofdegen.com/knights',
    'https://knightsofdegen.netlify.app/.netlify/functions/characters',
    'https://knightsofdegen.netlify.app/.netlify/functions/knights',
    'https://knightsofdegen.netlify.app/api/characters',
    'https://knightsofdegen.netlify.app/api/knights',
    
    // Contentful CMS patterns
    'https://cdn.contentful.com/spaces/b474hutgbdbv/entries',
    'https://preview.contentful.com/spaces/b474hutgbdbv/entries',
    
    // GraphQL patterns
    'https://knightsofdegen.netlify.app/graphql',
    'https://api.knightsofdegen.com/graphql',
    
    // Static JSON files
    'https://knightsofdegen.netlify.app/data/characters.json',
    'https://knightsofdegen.netlify.app/characters.json',
    'https://knightsofdegen.netlify.app/assets/knights.json'
  ];
  
  const workingEndpoints = [];
  
  for (const endpoint of potentialEndpoints) {
    try {
      console.log(`Testing API endpoint: ${endpoint}`);
      const result = await testAPIEndpoint(endpoint);
      
      if (result.success) {
        console.log(`✓ Working API found: ${endpoint}`);
        console.log(`Response type: ${result.contentType}`);
        console.log(`Data size: ${result.dataSize} bytes`);
        
        workingEndpoints.push({
          url: endpoint,
          contentType: result.contentType,
          dataSize: result.dataSize,
          sampleData: result.sampleData
        });
      }
    } catch (error) {
      console.log(`✗ Failed: ${endpoint} - ${error.message}`);
    }
  }
  
  return workingEndpoints;
}

function testAPIEndpoint(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname + urlObj.search,
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache'
      },
      timeout: 10000
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      const contentType = res.headers['content-type'] || '';
      
      if (res.statusCode !== 200) {
        resolve({ success: false, status: res.statusCode });
        return;
      }
      
      res.on('data', (chunk) => {
        data += chunk;
        // Limit data collection to prevent memory issues
        if (data.length > 1000000) { // 1MB limit
          res.destroy();
          resolve({ success: false, error: 'Response too large' });
        }
      });
      
      res.on('end', () => {
        try {
          // Try to parse as JSON
          let parsedData = null;
          let isValidJSON = false;
          
          if (contentType.includes('json') || data.trim().startsWith('{') || data.trim().startsWith('[')) {
            try {
              parsedData = JSON.parse(data);
              isValidJSON = true;
            } catch (e) {
              // Not valid JSON
            }
          }
          
          // Check if this looks like character/knight data
          const containsCharacterData = 
            data.toLowerCase().includes('knight') ||
            data.toLowerCase().includes('character') ||
            data.toLowerCase().includes('ctfassets') ||
            data.toLowerCase().includes('image') ||
            data.toLowerCase().includes('name');
          
          if (isValidJSON && containsCharacterData) {
            resolve({
              success: true,
              contentType,
              dataSize: data.length,
              sampleData: data.substring(0, 500) + (data.length > 500 ? '...' : ''),
              fullData: parsedData
            });
          } else if (containsCharacterData) {
            resolve({
              success: true,
              contentType,
              dataSize: data.length,
              sampleData: data.substring(0, 500) + (data.length > 500 ? '...' : ''),
              note: 'Contains character data but not JSON'
            });
          } else {
            resolve({ success: false, error: 'No character data found' });
          }
        } catch (error) {
          resolve({ success: false, error: error.message });
        }
      });
    });
    
    req.on('error', () => {
      resolve({ success: false, error: 'Network error' });
    });
    
    req.on('timeout', () => {
      req.destroy();
      resolve({ success: false, error: 'Timeout' });
    });
    
    req.end();
  });
}

// Try Contentful API directly
export async function tryContentfulAPI() {
  console.log('Attempting direct Contentful API access...');
  
  const contentfulEndpoints = [
    'https://cdn.contentful.com/spaces/b474hutgbdbv/entries?content_type=knight',
    'https://cdn.contentful.com/spaces/b474hutgbdbv/entries?content_type=character',
    'https://cdn.contentful.com/spaces/b474hutgbdbv/entries',
    'https://cdn.contentful.com/spaces/b474hutgbdbv/assets'
  ];
  
  const results = [];
  
  for (const endpoint of contentfulEndpoints) {
    try {
      console.log(`Testing Contentful endpoint: ${endpoint}`);
      const result = await testAPIEndpoint(endpoint);
      
      if (result.success) {
        console.log(`✓ Contentful API accessible: ${endpoint}`);
        results.push({
          endpoint,
          data: result.fullData,
          sample: result.sampleData
        });
      }
    } catch (error) {
      console.log(`✗ Contentful failed: ${endpoint}`);
    }
  }
  
  return results;
}

// Extract character data from discovered APIs
export async function extractCharacterData() {
  console.log('Discovering and extracting Knights character data...');
  
  // Try API discovery first
  const apiEndpoints = await discoverKnightsAPI();
  
  if (apiEndpoints.length > 0) {
    console.log(`Found ${apiEndpoints.length} working API endpoints`);
    
    for (const endpoint of apiEndpoints) {
      if (endpoint.fullData) {
        const characters = parseCharacterData(endpoint.fullData);
        if (characters.length > 0) {
          console.log(`✓ Extracted ${characters.length} characters from ${endpoint.url}`);
          return characters;
        }
      }
    }
  }
  
  // Try Contentful directly
  const contentfulResults = await tryContentfulAPI();
  
  if (contentfulResults.length > 0) {
    for (const result of contentfulResults) {
      if (result.data) {
        const characters = parseCharacterData(result.data);
        if (characters.length > 0) {
          console.log(`✓ Extracted ${characters.length} characters from Contentful`);
          return characters;
        }
      }
    }
  }
  
  console.log('No character data found through API discovery');
  return [];
}

function parseCharacterData(data) {
  const characters = [];
  
  try {
    // Handle different data structures
    let items = [];
    
    if (Array.isArray(data)) {
      items = data;
    } else if (data.items && Array.isArray(data.items)) {
      items = data.items;
    } else if (data.data && Array.isArray(data.data)) {
      items = data.data;
    } else if (data.characters && Array.isArray(data.characters)) {
      items = data.characters;
    }
    
    for (const item of items) {
      const character = extractCharacterFromItem(item);
      if (character) {
        characters.push(character);
      }
    }
  } catch (error) {
    console.error('Error parsing character data:', error);
  }
  
  return characters;
}

function extractCharacterFromItem(item) {
  try {
    // Extract character information from various possible structures
    const name = item.name || item.title || item.fields?.name || item.fields?.title || 'Unknown Knight';
    
    // Look for image URLs
    let imageUrl = null;
    
    // Direct image field
    if (item.image) {
      imageUrl = item.image;
    } else if (item.fields?.image) {
      imageUrl = item.fields.image;
    } else if (item.fields?.avatar?.fields?.file?.url) {
      imageUrl = 'https:' + item.fields.avatar.fields.file.url;
    } else if (item.fields?.profileImage?.fields?.file?.url) {
      imageUrl = 'https:' + item.fields.profileImage.fields.file.url;
    }
    
    // Only return character if we have both name and image
    if (name && imageUrl && imageUrl.includes('ctfassets')) {
      return {
        name,
        image: imageUrl,
        source: 'api_discovery'
      };
    }
  } catch (error) {
    // Skip malformed items
  }
  
  return null;
}