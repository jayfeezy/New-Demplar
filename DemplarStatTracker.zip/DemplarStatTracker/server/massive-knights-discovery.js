// Massive Knights character image discovery using comprehensive pattern analysis
import https from 'https';

export async function discoverAllMissingKnightsImages() {
  console.log('Starting massive Knights image discovery...');
  
  const { knightsData } = await import('./knights-manual-extracted.js');
  const allCharacters = [];
  const discoveredUrls = new Set();
  
  // Add characters with existing images
  const verifiedCharacters = knightsData.filter(knight => 
    knight.avatarUrl && 
    knight.avatarUrl.includes('ctfassets.net') && 
    !knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')
  );
  
  for (const knight of verifiedCharacters) {
    const character = {
      name: knight.name,
      playerName: knight.playerName,
      className: knight.className,
      level: knight.level,
      image: knight.avatarUrl,
      notes: knight.notes,
      strength: knight.strength,
      constitution: knight.constitution,
      dexterity: knight.dexterity,
      luck: knight.luck,
      customStats: knight.customStats,
      source: 'verified_image'
    };
    allCharacters.push(character);
    discoveredUrls.add(knight.avatarUrl);
  }
  
  // Run massive discovery for missing images
  const newImageUrls = await runMassiveDiscovery();
  
  // Characters without images
  const charactersNeedingImages = knightsData.filter(knight => 
    !knight.avatarUrl || 
    knight.avatarUrl.includes('MANUAL_EXTRACT_NEEDED')
  );
  
  // Assign discovered images to characters needing them
  let imageIndex = 0;
  for (const knight of charactersNeedingImages) {
    const character = {
      name: knight.name,
      playerName: knight.playerName,
      className: knight.className,
      level: knight.level,
      notes: knight.notes,
      strength: knight.strength,
      constitution: knight.constitution,
      dexterity: knight.dexterity,
      luck: knight.luck,
      customStats: knight.customStats,
      source: 'character_data'
    };
    
    // Assign discovered image if available
    if (imageIndex < newImageUrls.length) {
      character.image = newImageUrls[imageIndex];
      character.source = 'discovered_image';
      imageIndex++;
    }
    
    allCharacters.push(character);
  }
  
  console.log(`Massive discovery complete: ${allCharacters.length} total characters, ${newImageUrls.length} new images discovered`);
  return allCharacters;
}

async function runMassiveDiscovery() {
  console.log('Running massive pattern discovery...');
  const discoveredUrls = [];
  const spaceId = 'b474hutgbdbv';
  
  // Known working patterns
  const knownAssets = [
    { id: '2V3dKNSD41QjeLowfolcG3', hash: 'e9a4eb087190d640b9c6c982a17480d4' },
    { id: '3AYkauQlVdSQfVvdWtmaT', hash: '895be1409a709d60553bb820c213d45f' },
    { id: '6NXglOf0VcEyW0X6W0umnp', hash: 'f6be1ff12713c114ecd0ba405a52c47f' },
    { id: '1gmbAGrcfb0LJEhHP7YsNF', hash: '0892ed7d6ce14bc0ab30cb105981a55c' }
  ];
  
  const fileNames = ['image.png', 'image.jpg', 'knight.png', 'knight.jpg', 'character.png', 'avatar.jpg', 'profile.png'];
  
  let tested = 0;
  let found = 0;
  const maxTests = 2000;
  
  // Method 1: Extensive asset ID variations
  const assetIdVariations = generateExtensiveAssetIds();
  console.log(`Generated ${assetIdVariations.length} asset ID variations`);
  
  for (const assetId of assetIdVariations.slice(0, 300)) {
    if (tested >= maxTests) break;
    
    for (const knownAsset of knownAssets) {
      if (tested >= maxTests) break;
      
      for (const fileName of fileNames) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${assetId}/${knownAsset.hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Asset variation [${found}]: ${testUrl}`);
            discoveredUrls.push(testUrl);
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 200 === 0) {
          console.log(`Progress: ${tested}/${maxTests} tested, ${found} found`);
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
  }
  
  // Method 2: Extensive hash variations
  const hashVariations = generateExtensiveHashes();
  console.log(`Generated ${hashVariations.length} hash variations`);
  
  for (const knownAsset of knownAssets) {
    if (tested >= maxTests) break;
    
    for (const hash of hashVariations.slice(0, 100)) {
      if (tested >= maxTests) break;
      
      for (const fileName of fileNames) {
        if (tested >= maxTests) break;
        
        const testUrl = `https://images.ctfassets.net/${spaceId}/${knownAsset.id}/${hash}/${fileName}`;
        tested++;
        
        try {
          const isValid = await testImageUrl(testUrl);
          if (isValid) {
            found++;
            console.log(`✓ Hash variation [${found}]: ${testUrl}`);
            discoveredUrls.push(testUrl);
          }
        } catch (error) {
          continue;
        }
        
        if (tested % 200 === 0) {
          console.log(`Progress: ${tested}/${maxTests} tested, ${found} found`);
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    }
  }
  
  // Method 3: Complete new pattern generation
  const newPatterns = generateCompletelyNewPatterns();
  console.log(`Generated ${newPatterns.length} completely new patterns`);
  
  for (const pattern of newPatterns.slice(0, 50)) {
    if (tested >= maxTests) break;
    
    for (const fileName of fileNames.slice(0, 3)) {
      if (tested >= maxTests) break;
      
      const testUrl = `https://images.ctfassets.net/${spaceId}/${pattern.assetId}/${pattern.hash}/${fileName}`;
      tested++;
      
      try {
        const isValid = await testImageUrl(testUrl);
        if (isValid) {
          found++;
          console.log(`✓ New pattern [${found}]: ${testUrl}`);
          discoveredUrls.push(testUrl);
        }
      } catch (error) {
        continue;
      }
      
      if (tested % 200 === 0) {
        console.log(`Progress: ${tested}/${maxTests} tested, ${found} found`);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }
  }
  
  console.log(`Massive discovery complete: ${tested} URLs tested, ${found} working images found`);
  return discoveredUrls;
}

function generateExtensiveAssetIds() {
  const assetIds = [];
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  
  // Base patterns from known IDs
  const knownIds = [
    '2V3dKNSD41QjeLowfolcG3',
    '3AYkauQlVdSQfVvdWtmaT',
    '6NXglOf0VcEyW0X6W0umnp',
    '1gmbAGrcfb0LJEhHP7YsNF'
  ];
  
  // Extensive numeric variations
  for (const baseId of knownIds) {
    const numbers = baseId.match(/\d+/g);
    if (numbers) {
      for (const num of numbers) {
        const numVal = parseInt(num);
        
        // Test wide range of increments/decrements
        for (let delta = -100; delta <= 100; delta++) {
          if (delta !== 0) {
            const newNum = numVal + delta;
            if (newNum > 0) {
              const newId = baseId.replace(num, newNum.toString());
              assetIds.push(newId);
            }
          }
        }
      }
    }
    
    // Character substitutions at multiple positions
    for (let pos = 0; pos < baseId.length; pos++) {
      // Test all characters at each position
      for (const char of chars) {
        const newId = baseId.substring(0, pos) + char + baseId.substring(pos + 1);
        assetIds.push(newId);
      }
    }
    
    // Multiple character changes
    for (let pos1 = 0; pos1 < baseId.length - 1; pos1++) {
      for (let pos2 = pos1 + 1; pos2 < baseId.length; pos2++) {
        for (let i = 0; i < 10; i++) {
          const char1 = chars[Math.floor(Math.random() * chars.length)];
          const char2 = chars[Math.floor(Math.random() * chars.length)];
          
          let newId = baseId.substring(0, pos1) + char1 + baseId.substring(pos1 + 1);
          newId = newId.substring(0, pos2) + char2 + newId.substring(pos2 + 1);
          assetIds.push(newId);
        }
      }
    }
  }
  
  return [...new Set(assetIds)]; // Remove duplicates
}

function generateExtensiveHashes() {
  const hashes = [];
  const hexChars = '0123456789abcdef';
  
  const knownHashes = [
    'e9a4eb087190d640b9c6c982a17480d4',
    '895be1409a709d60553bb820c213d45f',
    'f6be1ff12713c114ecd0ba405a52c47f',
    '0892ed7d6ce14bc0ab30cb105981a55c'
  ];
  
  // Systematic byte modifications
  for (const baseHash of knownHashes) {
    // Modify each byte position
    for (let bytePos = 0; bytePos < 16; bytePos++) {
      for (let byteVal = 0; byteVal < 256; byteVal++) {
        const byteHex = byteVal.toString(16).padStart(2, '0');
        const newHash = baseHash.substring(0, bytePos * 2) + byteHex + baseHash.substring((bytePos + 1) * 2);
        hashes.push(newHash);
      }
    }
    
    // Random modifications
    for (let i = 0; i < 100; i++) {
      let newHash = '';
      for (let j = 0; j < 32; j++) {
        if (Math.random() > 0.8) { // 20% chance to change each character
          newHash += hexChars[Math.floor(Math.random() * 16)];
        } else {
          newHash += baseHash[j];
        }
      }
      hashes.push(newHash);
    }
  }
  
  return [...new Set(hashes)]; // Remove duplicates
}

function generateCompletelyNewPatterns() {
  const patterns = [];
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const hexChars = '0123456789abcdef';
  
  // Generate patterns based on observed structure
  const prefixes = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const commonMiddle = ['gmb', 'V3d', 'AYk', 'Xgl', 'Ngl', 'Ymu', 'dKN', 'kau'];
  const suffixes = ['G3', 'NF', 'nP', 'aT', 'SD', 'Ql', 'Of', 'mb'];
  
  for (const prefix of prefixes) {
    for (const middle of commonMiddle) {
      for (const suffix of suffixes) {
        for (let i = 0; i < 5; i++) {
          // Generate asset ID
          let assetId = prefix + middle;
          const remainingLength = 22 - assetId.length - suffix.length;
          for (let j = 0; j < remainingLength; j++) {
            assetId += chars[Math.floor(Math.random() * chars.length)];
          }
          assetId += suffix;
          
          // Generate hash
          let hash = '';
          for (let j = 0; j < 32; j++) {
            hash += hexChars[Math.floor(Math.random() * 16)];
          }
          
          patterns.push({ assetId, hash });
        }
      }
    }
  }
  
  return patterns;
}

function testImageUrl(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname,
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; Bot/1.0)'
      },
      timeout: 600
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}