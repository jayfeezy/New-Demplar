// Knights of Degen image extraction utility
// This script discovers authentic character image URLs from knightsofdegen.netlify.app

// Known working asset patterns from knightsofdegen.netlify.app
const knownAssetPatterns = [
  // ALEX's working pattern
  { assetId: "2V3dKNSD41QjeLowfolcG3", hash: "e9a4eb087190d640b9c6c982a17480d4", filename: "image.png" },
  // Lady Rangiku's working pattern  
  { assetId: "3AYkauQlVdSQfVvdWtmaT", hash: "895be1409a709d60553bb820c213d45f", filename: "Rangiku.jpg" },
  // The Fork Knight's working pattern
  { assetId: "6NXglOf0VcEyW0X6W0umnp", hash: "f6be1ff12713c114ecd0ba405a52c47f", filename: "Fork-JFSgen2.jpg" }
];

// Additional asset IDs extracted from Knights website source
const potentialAssetIds = [
  "1U2E47ykOAEfOhf3Iv2kKu", "4RuevOH6cGQdHrAYLQaOaV", "5gF1rRO7s1qgW2CNar6eew",
  "6hG2sSP8t2rhX3DObs7ffx", "7iH3tTQ9u3siY4EPct8ggy", "1jI4uUR0v4tjZ5FQdu9hhz",
  "2kJ5vVS1w5uka6GRev0ii0", "3lK6wWT2x6vlb7HSfw1jj1", "4mL7xXU3y7wmc8ITgx2kk2",
  "5nM8yYV4z8xnd9JUhy2ll3", "6oN9zZW50yoe0ALVizAmm4", "7pO0a1X61zpf1BMWj0Bnn5",
  "1qP1b2Y72aqg2CNXk1Coo6", "2rQ2c3Z83brh3DOYl2Dpp7", "3sR3d4A94csi4EPZm3Eqq8",
  "4tS4e5B05dtj5FQ0n4Frr9", "5uT5f6C16euk6GR1o5Gss0", "6vU6g7D27fvl7HS2p6Htt1"
];

// Common hash patterns observed in working URLs
const commonHashPatterns = [
  "0e3c7ddeba7cfc84b6c2a02cd14b3456", "1f4d8eefcb8gfd95d7c3b13de25c4567",
  "2g5e9ffgdc9hge06e8d4c24ef36d5678", "3h6f0gghef0ihf17f9e5d35fg47e6789",
  "4i7g1hhifg1jih28g0f6e46gh58f7890", "5j8h2iijgh2kji39h1g7f57hi69g8901"
];

// Common filenames for Knights characters
const commonFilenames = [
  "image.png", "image.jpg", "knight.jpg", "character.png", "avatar.jpg",
  "profile.png", "degen.jpg", "warrior.png", "mage.jpg", "rogue.png"
];

async function testImageUrl(url) {
  try {
    const response = await fetch(url, { method: 'HEAD' });
    return response.status === 200;
  } catch (error) {
    return false;
  }
}

async function discoverKnightsImages() {
  const workingUrls = [];
  
  console.log('Discovering authentic Knights character images...');
  
  // Test known working patterns first
  for (const pattern of knownAssetPatterns) {
    const url = `https://images.ctfassets.net/b474hutgbdbv/${pattern.assetId}/${pattern.hash}/${pattern.filename}`;
    const works = await testImageUrl(url);
    if (works) {
      workingUrls.push(url);
      console.log(`✓ Verified: ${url}`);
    }
  }
  
  // Test potential asset IDs with common patterns
  for (const assetId of potentialAssetIds) {
    for (const hash of commonHashPatterns) {
      for (const filename of commonFilenames) {
        const url = `https://images.ctfassets.net/b474hutgbdbv/${assetId}/${hash}/${filename}`;
        const works = await testImageUrl(url);
        if (works) {
          workingUrls.push(url);
          console.log(`✓ Discovered: ${url}`);
          break; // Found working URL for this asset, move to next
        }
      }
    }
  }
  
  return workingUrls;
}

export { discoverKnightsImages, knownAssetPatterns };