// HTTP-based Knights character extraction without browser automation
import https from 'https';
import { URL } from 'url';

export async function extractKnightsViaHTTP() {
  console.log('Starting HTTP extraction of Knights character data...');
  
  try {
    // Get the main page HTML
    const pageHtml = await fetchPageHTML('https://knightsofdegen.netlify.app/');
    
    // Extract Contentful image URLs from HTML
    const imageUrls = extractContentfulURLsFromHTML(pageHtml);
    
    if (imageUrls.length > 0) {
      console.log(`Found ${imageUrls.length} Contentful image URLs in page HTML`);
      
      // Validate URLs and extract character data
      const validatedCharacters = await validateAndEnrichImageURLs(imageUrls);
      
      return validatedCharacters;
    }
    
    console.log('No Contentful URLs found in page HTML');
    return [];
    
  } catch (error) {
    console.error('HTTP extraction error:', error);
    throw error;
  }
}

function fetchPageHTML(url) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname,
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      },
      timeout: 15000
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        if (res.statusCode === 200) {
          resolve(data);
        } else {
          reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    
    req.end();
  });
}

function extractContentfulURLsFromHTML(html) {
  const imageUrls = [];
  
  // Look for Contentful image URLs in various patterns
  const patterns = [
    // Direct img src attributes
    /src="(https:\/\/images\.ctfassets\.net\/[^"]+)"/g,
    // Background images in style attributes
    /background-image:\s*url\(['"]?(https:\/\/images\.ctfassets\.net\/[^'")\s]+)['"]?\)/g,
    // JavaScript string literals
    /'(https:\/\/images\.ctfassets\.net\/[^']+)'/g,
    /"(https:\/\/images\.ctfassets\.net\/[^"]+)"/g,
    // Protocol-relative URLs
    /src="(\/\/images\.ctfassets\.net\/[^"]+)"/g,
    // Data attributes
    /data-[^=]*="(https:\/\/images\.ctfassets\.net\/[^"]+)"/g
  ];
  
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(html)) !== null) {
      let url = match[1];
      
      // Add protocol if missing
      if (url.startsWith('//')) {
        url = 'https:' + url;
      }
      
      // Only include character/knight images (filter out icons, backgrounds, etc.)
      if (url.includes('ctfassets.net') && 
          (url.includes('.jpg') || url.includes('.png') || url.includes('.webp')) &&
          !url.includes('icon') && 
          !url.includes('background') &&
          !url.includes('logo')) {
        
        // Remove duplicates
        if (!imageUrls.some(existing => existing.url === url)) {
          imageUrls.push({
            url: url,
            source: 'html_extraction'
          });
        }
      }
    }
  }
  
  return imageUrls;
}

async function validateAndEnrichImageURLs(imageUrls) {
  console.log(`Validating ${imageUrls.length} extracted image URLs...`);
  
  const validCharacters = [];
  
  for (let i = 0; i < imageUrls.length; i++) {
    const imageData = imageUrls[i];
    
    try {
      // Test if image URL is accessible
      const isValid = await testImageURL(imageData.url);
      
      if (isValid) {
        // Extract character name from URL or use generic name
        const characterName = extractCharacterNameFromURL(imageData.url) || `Knight Character ${i + 1}`;
        
        validCharacters.push({
          name: characterName,
          image: imageData.url,
          source: 'http_extraction'
        });
        
        console.log(`✓ Valid image: ${characterName} - ${imageData.url}`);
      } else {
        console.log(`✗ Invalid image: ${imageData.url}`);
      }
    } catch (error) {
      console.log(`✗ Error validating ${imageData.url}: ${error.message}`);
    }
  }
  
  return validCharacters;
}

function testImageURL(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname + urlObj.search,
      method: 'HEAD', // Only get headers, not the full image
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      timeout: 5000
    };
    
    const req = https.request(options, (res) => {
      const isValid = res.statusCode === 200 && 
                     res.headers['content-type'] && 
                     res.headers['content-type'].startsWith('image/');
      resolve(isValid);
    });
    
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    
    req.end();
  });
}

function extractCharacterNameFromURL(url) {
  try {
    // Try to extract meaningful name from URL path
    const urlPath = new URL(url).pathname;
    const filename = urlPath.split('/').pop();
    
    // Remove file extension
    const nameWithoutExt = filename.replace(/\.(jpg|png|webp|jpeg)$/i, '');
    
    // If filename looks like a hash, return null to use generic name
    if (/^[a-f0-9]+$/i.test(nameWithoutExt) || nameWithoutExt === 'image') {
      return null;
    }
    
    // Clean up the name
    return nameWithoutExt
      .replace(/[-_]/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase())
      .trim();
    
  } catch (error) {
    return null;
  }
}

// Alternative method: Try to find JavaScript files that contain character data
export async function extractFromJavaScriptBundles() {
  console.log('Searching for character data in JavaScript bundles...');
  
  try {
    const pageHtml = await fetchPageHTML('https://knightsofdegen.netlify.app/');
    
    // Extract JavaScript file URLs
    const jsUrls = extractJavaScriptURLs(pageHtml);
    
    console.log(`Found ${jsUrls.length} JavaScript files to analyze`);
    
    const allCharacters = [];
    
    for (const jsUrl of jsUrls) {
      try {
        console.log(`Analyzing JavaScript file: ${jsUrl}`);
        const jsContent = await fetchPageHTML(jsUrl);
        
        // Look for character data in JavaScript
        const characters = extractCharacterDataFromJS(jsContent);
        allCharacters.push(...characters);
        
      } catch (error) {
        console.log(`Failed to analyze ${jsUrl}: ${error.message}`);
      }
    }
    
    return allCharacters;
    
  } catch (error) {
    console.error('JavaScript bundle extraction error:', error);
    return [];
  }
}

function extractJavaScriptURLs(html) {
  const jsUrls = [];
  const scriptRegex = /<script[^>]+src="([^"]+)"[^>]*>/g;
  
  let match;
  while ((match = scriptRegex.exec(html)) !== null) {
    let url = match[1];
    
    // Convert relative URLs to absolute
    if (url.startsWith('/')) {
      url = 'https://knightsofdegen.netlify.app' + url;
    }
    
    // Only include relevant JavaScript files
    if (url.includes('.js') && !url.includes('vendor') && !url.includes('polyfill')) {
      jsUrls.push(url);
    }
  }
  
  return jsUrls;
}

function extractCharacterDataFromJS(jsContent) {
  const characters = [];
  
  // Look for Contentful URLs in the JavaScript
  const contentfulRegex = /https:\/\/images\.ctfassets\.net\/[a-zA-Z0-9\/\-_\.]+/g;
  const urls = jsContent.match(contentfulRegex) || [];
  
  // Look for character names that might be associated with these URLs
  const nameRegex = /"name":\s*"([^"]+)"/g;
  const names = [];
  let nameMatch;
  while ((nameMatch = nameRegex.exec(jsContent)) !== null) {
    names.push(nameMatch[1]);
  }
  
  // Combine URLs with names if available
  urls.forEach((url, index) => {
    if (url.includes('.jpg') || url.includes('.png') || url.includes('.webp')) {
      const name = names[index] || `Knight Character ${index + 1}`;
      characters.push({
        name: name,
        image: url,
        source: 'javascript_extraction'
      });
    }
  });
  
  return characters;
}