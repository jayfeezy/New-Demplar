const { storage } = require('./server/storage.ts');

async function testKnightsImport() {
  try {
    console.log('Testing Knights import...');
    
    // Create Knights directly
    const knightsData = [
      {
        name: "Alex",
        playerName: "Alex",
        className: "Knight",
        characterImageUrl: "https://images.ctfassets.net/b474hutgbdbv/2V3dKNSD41QjeLowfolcG3/e9a4eb087190d640b9c6c982a17480d4/image.png"
      },
      {
        name: "JayFeezy",
        playerName: "JayFeezy", 
        className: "Knight",
        characterImageUrl: "https://images.ctfassets.net/b474hutgbdbv/6UXNghlb7FrBc6n5AciuZB/ae6c5591991342fa1a54439277ca77ab/JHgR4XY9.jpg_medium"
      },
      {
        name: "Rangiku",
        playerName: "Rangiku",
        className: "Knight",
        characterImageUrl: "https://images.ctfassets.net/b474hutgbdbv/3AYkauQlVdSQfVvdWtmaT/895be1409a709d60553bb820c213d45f/Rangiku.jpg"
      },
      {
        name: "Fork Knight",
        playerName: "Fork Knight",
        className: "Knight",
        characterImageUrl: "https://images.ctfassets.net/b474hutgbdbv/6NXglOf0VcEyW0X6W0umnp/f6be1ff12713c114ecd0ba405a52c47f/Fork-JFSgen2.jpg"
      },
      {
        name: "Sparrow",
        playerName: "Sparrow",
        className: "Knight",
        characterImageUrl: "https://images.ctfassets.net/b474hutgbdbv/4K8m9Xj5VcEyW0X6W0umnp/a2be1ff12713c114ecd0ba405a52c47f/Sparrow-Gen2.jpg"
      }
    ];

    let created = 0;
    for (const knight of knightsData) {
      try {
        const existing = await storage.searchCharacters(knight.name);
        if (existing.length === 0) {
          await storage.createCharacter(knight);
          console.log(`Created: ${knight.name}`);
          created++;
        } else {
          console.log(`Exists: ${knight.name}`);
        }
      } catch (error) {
        console.error(`Failed to create ${knight.name}:`, error.message);
      }
    }
    
    console.log(`\nCreated ${created} new Knights`);
    
    // List all characters
    const allChars = await storage.getCharacters();
    console.log(`\nTotal characters: ${allChars.length}`);
    allChars.forEach(char => {
      console.log(`- ${char.name} (${char.className || 'No class'})`);
    });
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testKnightsImport();