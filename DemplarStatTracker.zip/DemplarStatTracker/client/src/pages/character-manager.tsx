import { useState } from "react";
import CharacterHeader from "@/components/character-header";
import CharacterProfile from "@/components/character-profile";
import CharacterStats from "@/components/character-stats";
import CharacterInventory from "@/components/character-inventory";
import CharacterSessions from "@/components/character-sessions";
import CharacterLookup from "@/components/character-lookup";
import CharacterAdmin from "@/components/character-admin";
import CharacterAdvanced from "@/components/character-advanced";
import { useCharacters } from "@/hooks/use-characters";
import { useAuth } from "@/hooks/use-auth";
import type { Character } from "@shared/schema";

type Tab = "profile" | "stats" | "inventory" | "sessions" | "lookup" | "advanced" | "admin";

export default function CharacterManager() {
  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const { data: characters = [], isLoading } = useCharacters();
  const { isMaster } = useAuth();

  // Auto-select first character if none selected
  if (!selectedCharacter && characters && characters.length > 0) {
    setSelectedCharacter(characters[0]);
  }

  const navItems = [
    { id: "profile" as Tab, label: "Profile", icon: "fas fa-user" },
    { id: "stats" as Tab, label: "Stats & Level", icon: "fas fa-chart-bar" },
    { id: "inventory" as Tab, label: "Inventory", icon: "fas fa-backpack" },
    { id: "sessions" as Tab, label: "Session Log", icon: "fas fa-scroll" },
    { id: "advanced" as Tab, label: "Advanced", icon: "fas fa-magic" },
    { id: "lookup" as Tab, label: "Character Lookup", icon: "fas fa-search" },
    ...(isMaster ? [{ id: "admin" as Tab, label: "Admin", icon: "fas fa-shield-alt" }] : []),
  ];

  return (
    <div className="min-h-screen bg-fantasy-parchment font-ui text-gray-800">
      <CharacterHeader 
        selectedCharacter={selectedCharacter}
        onCharacterChange={setSelectedCharacter}
      />
      
      {/* Navigation */}
      <nav className="bg-white shadow-md border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`py-4 px-2 border-b-2 font-medium whitespace-nowrap transition-colors ${
                  activeTab === item.id
                    ? "border-fantasy-deep text-fantasy-deep"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                <i className={`${item.icon} mr-2`}></i>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === "profile" && (
          <CharacterProfile 
            character={selectedCharacter}
            onCharacterUpdate={setSelectedCharacter}
          />
        )}
        
        {activeTab === "stats" && (
          <CharacterStats 
            character={selectedCharacter}
            onCharacterUpdate={setSelectedCharacter}
          />
        )}
        
        {activeTab === "inventory" && (
          <CharacterInventory 
            character={selectedCharacter}
            onCharacterUpdate={setSelectedCharacter}
          />
        )}
        
        {activeTab === "sessions" && (
          <CharacterSessions character={selectedCharacter} />
        )}
        
        {activeTab === "advanced" && (
          <CharacterAdvanced 
            character={selectedCharacter}
            onCharacterUpdate={setSelectedCharacter}
          />
        )}
        
        {activeTab === "lookup" && (
          <CharacterLookup onCharacterSelect={setSelectedCharacter} />
        )}
        
        {activeTab === "admin" && isMaster && (
          <CharacterAdmin />
        )}
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button className="bg-fantasy-gold hover:bg-yellow-300 text-fantasy-deep rounded-full w-14 h-14 shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-110">
          <i className="fas fa-dice-d20 text-xl"></i>
        </button>
      </div>
    </div>
  );
}
