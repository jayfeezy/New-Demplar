import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useUpdateCharacter } from "@/hooks/use-characters";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import type { Character, InventoryItem } from "@shared/schema";

interface CharacterInventoryProps {
  character: Character | null;
  onCharacterUpdate: (character: Character) => void;
}

export default function CharacterInventory({ character, onCharacterUpdate }: CharacterInventoryProps) {
  const [newItemName, setNewItemName] = useState("");
  const [newItemType, setNewItemType] = useState<InventoryItem["type"]>("misc");
  const [newItemQuantity, setNewItemQuantity] = useState("1");
  const [newItemDescription, setNewItemDescription] = useState("");
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  const updateCharacter = useUpdateCharacter();
  const { toast } = useToast();
  const { isMaster } = useAuth();

  const handleAddItem = async () => {
    if (!character || !newItemName.trim() || !isMaster) return;

    try {
      const newItem: InventoryItem = {
        id: Date.now().toString(),
        name: newItemName.trim(),
        type: newItemType,
        quantity: parseInt(newItemQuantity) || 1,
        description: newItemDescription.trim() || undefined,
        equipped: false,
      };

      const updatedInventory = [...(character.inventory || []), newItem];
      
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: { inventory: updatedInventory },
      });

      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
        setNewItemName("");
        setNewItemDescription("");
        setNewItemQuantity("1");
        setShowItemDialog(false);
        toast({
          title: "Item Added",
          description: `${newItem.name} has been added to inventory!`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add item. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveItem = async (itemId: string) => {
    if (!character || !isMaster) return;

    try {
      const updatedInventory = character.inventory?.filter(item => item.id !== itemId) || [];
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: { inventory: updatedInventory },
      });

      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
        toast({
          title: "Item Removed",
          description: "Item has been removed from inventory.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove item. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddQuest = async () => {
    if (!character || !isMaster) return;
    // Quest adding logic would go here
  };

  if (!character) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">
          Select a character to view inventory
        </CardContent>
      </Card>
    );
  }

  const getRarityColor = (rarity?: string) => {
    switch (rarity) {
      case "legendary": return "bg-purple-100 text-purple-800";
      case "epic": return "bg-indigo-100 text-indigo-800";
      case "rare": return "bg-blue-100 text-blue-800";
      case "uncommon": return "bg-green-100 text-green-800";
      case "common": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Edit Toggle */}
      {isMaster && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl font-bold text-fantasy-gold">
              Inventory & Quests
            </CardTitle>
            <Button
              variant={isEditing ? "destructive" : "outline"}
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? "Cancel" : "Edit"}
            </Button>
          </CardHeader>
        </Card>
      )}

      <Tabs defaultValue="inventory" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="inventory">Regular Items</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="events">Event Items</TabsTrigger>
          <TabsTrigger value="quests">Quests</TabsTrigger>
          <TabsTrigger value="weapon">Weapon</TabsTrigger>
        </TabsList>

        {/* Regular Inventory */}
        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg text-fantasy-gold">Regular Inventory</CardTitle>
              {isEditing && isMaster && (
                <Dialog open={showItemDialog} onOpenChange={setShowItemDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm">Add Item</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Item</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="itemName">Item Name</Label>
                        <Input
                          id="itemName"
                          value={newItemName}
                          onChange={(e) => setNewItemName(e.target.value)}
                          placeholder="Enter item name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="itemType">Type</Label>
                        <Select value={newItemType} onValueChange={(value: InventoryItem["type"]) => setNewItemType(value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="weapon">Weapon</SelectItem>
                            <SelectItem value="armor">Armor</SelectItem>
                            <SelectItem value="consumable">Consumable</SelectItem>
                            <SelectItem value="quest">Quest</SelectItem>
                            <SelectItem value="misc">Miscellaneous</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="itemQuantity">Quantity</Label>
                        <Input
                          id="itemQuantity"
                          type="number"
                          value={newItemQuantity}
                          onChange={(e) => setNewItemQuantity(e.target.value)}
                          min="1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="itemDescription">Description</Label>
                        <Textarea
                          id="itemDescription"
                          value={newItemDescription}
                          onChange={(e) => setNewItemDescription(e.target.value)}
                          placeholder="Item description (optional)"
                        />
                      </div>
                      <Button onClick={handleAddItem} className="w-full">
                        Add Item
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {character.inventory && character.inventory.length > 0 ? (
                  character.inventory.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div>
                          <h4 className="font-medium">{item.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {item.type} • Quantity: {item.quantity}
                          </p>
                          {item.description && (
                            <p className="text-xs text-muted-foreground mt-1">{item.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.rarity && (
                          <Badge className={getRarityColor(item.rarity)}>
                            {item.rarity}
                          </Badge>
                        )}
                        {item.equipped && (
                          <Badge variant="outline">Equipped</Badge>
                        )}
                        {isEditing && isMaster && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleRemoveItem(item.id)}
                          >
                            Remove
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">No items in inventory</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Equipment */}
        <TabsContent value="equipment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Equipped Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {character.equipment && character.equipment.length > 0 ? (
                  character.equipment.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-fantasy-gold">{item.name}</h4>
                        <Badge className={getRarityColor(item.rarity)}>
                          {item.rarity || 'common'}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                      {item.effects && (
                        <p className="text-xs font-medium">Effects: {item.effects}</p>
                      )}
                      {item.mainStat && (
                        <p className="text-xs">Main Stat: {item.mainStat}</p>
                      )}
                      {item.bonusStats && (
                        <p className="text-xs">Bonus: {item.bonusStats}</p>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">No equipment equipped</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Event Items */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Event Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {character.eventItems && character.eventItems.length > 0 ? (
                  character.eventItems.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{item.name}</h4>
                        {item.description && (
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        )}
                      </div>
                      <Badge variant="outline" className="bg-yellow-50 text-yellow-800">
                        x{item.quantity}
                      </Badge>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">No event items</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Quests */}
        <TabsContent value="quests" className="space-y-4">
          <div className="grid gap-4">
            {/* Active Quests */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Active Quests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {character.activeQuests && character.activeQuests.length > 0 ? (
                    character.activeQuests.map((quest, index) => (
                      <div key={index} className="border rounded-lg p-4 space-y-2">
                        <h4 className="font-bold">{quest.name}</h4>
                        <p className="text-sm text-muted-foreground">{quest.description}</p>
                        <div className="flex gap-2">
                          {quest.location && (
                            <Badge variant="outline">
                              <i className="fas fa-map-marker-alt mr-1"></i>
                              {quest.location}
                            </Badge>
                          )}
                          {quest.questGiver && (
                            <Badge variant="outline">
                              <i className="fas fa-user mr-1"></i>
                              {quest.questGiver}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No active quests</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quest Items */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Quest Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {character.questItems && character.questItems.length > 0 ? (
                    character.questItems.map((item, index) => (
                      <div key={index} className="border rounded-lg p-3 space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{item.name}</h4>
                          <Badge variant="outline" className="text-xs">{item.source}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground text-center py-8">No quest items</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Weapon Details */}
        <TabsContent value="weapon" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Primary Weapon</CardTitle>
            </CardHeader>
            <CardContent>
              {character.weapon ? (
                <div className="space-y-4">
                  <div className="border rounded-lg p-4 space-y-3">
                    <h3 className="text-xl font-bold text-fantasy-gold">{character.weapon.name}</h3>
                    <p className="text-muted-foreground">{character.weapon.description}</p>
                    
                    <div className="space-y-2">
                      <h4 className="font-semibold">Effects:</h4>
                      <div className="flex flex-wrap gap-2">
                        {character.weapon.effects?.map((effect, index) => (
                          <Badge key={index} variant="outline" className="text-sm">
                            {effect}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {character.weapon.bonusStats && (
                      <div>
                        <h4 className="font-semibold">Bonus Stats:</h4>
                        <p className="text-sm text-muted-foreground">{character.weapon.bonusStats}</p>
                      </div>
                    )}
                  </div>

                  {/* Support Skill */}
                  {character.supportSkill && (
                    <div className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold">Support Skill: {character.supportSkill.name}</h4>
                        <Badge variant="secondary">Level {character.supportSkill.level}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{character.supportSkill.description}</p>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">No weapon equipped</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}