import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ChevronDown } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCreateCharacter, useCharacters, useDeleteCharacter } from "@/hooks/use-characters";
import { useToast } from "@/hooks/use-toast";
import { insertCharacterSchema, type Character } from "@shared/schema";
import type { z } from "zod";
import demplarBg1 from "@assets/Gemini_Generated_Image_8nvjkv8nvjkv8nvj.png";
import demplarBg2 from "@assets/Gemini_Generated_Image_sdfgptsdfgptsdfg.png";
import KnightAvatarBrowser from "./knight-avatar-browser";

// Utility function to create Twitter links
const formatTwitterHandle = (handle: string) => {
  if (!handle) return null;
  
  const cleanHandle = handle.replace(/^@/, '').trim();
  if (!cleanHandle) return null;
  
  return {
    display: `@${cleanHandle}`,
    url: `https://twitter.com/${cleanHandle}`
  };
};

const characterFormSchema = insertCharacterSchema.extend({
  name: insertCharacterSchema.shape.name.min(1, "Character name is required"),
  playerName: insertCharacterSchema.shape.playerName.min(1, "Player name is required"),
  className: insertCharacterSchema.shape.className.min(1, "Class is required"),
});

type CharacterFormData = z.infer<typeof characterFormSchema>;

interface CharacterHeaderProps {
  selectedCharacter: Character | null;
  onCharacterChange: (character: Character) => void;
}

export default function CharacterHeader({ selectedCharacter, onCharacterChange }: CharacterHeaderProps) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isAvatarBrowserOpen, setIsAvatarBrowserOpen] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const { data: characters } = useCharacters();
  const createCharacter = useCreateCharacter();
  const deleteCharacter = useDeleteCharacter();
  const { toast } = useToast();

  const form = useForm<CharacterFormData>({
    resolver: zodResolver(characterFormSchema),
    defaultValues: {
      name: "",
      playerName: "",
      className: "",
      faction: "",
      backstory: "",
      avatarUrl: "",
      level: 1,
      currentXP: 0,
      nextLevelXP: 1000,
      gold: 0,
      strength: 0,
      dexterity: 0,
      intelligence: 0,
      wisdom: 0,
      constitution: 0,
      charisma: 0,
      powerLevel: 1,
      loreLevel: 1,
      arenaRanking: "N/A",
      notoriety: "unknown",
      customStats: {},
      equipment: [],
      inventory: [],
      notes: "",
    },
  });

  const onSubmit = async (data: CharacterFormData) => {
    try {
      const newCharacter = await createCharacter.mutateAsync(data);
      onCharacterChange(newCharacter);
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Character Created",
        description: `${newCharacter.name} has been successfully created!`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create character. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleShare = () => {
    if (!selectedCharacter) return;
    
    const characterData = {
      name: selectedCharacter.name,
      class: selectedCharacter.className,
      level: selectedCharacter.level,
      faction: selectedCharacter.faction,
      player: selectedCharacter.playerName,
    };
    
    const shareText = `🧙‍♂️ ${characterData.name} (Level ${characterData.level} ${characterData.class}) - ${characterData.faction ? `${characterData.faction} member` : 'Independent adventurer'} played by ${characterData.player} #Demplar`;
    
    if (navigator.share) {
      navigator.share({
        title: `${characterData.name} - Demplar Character`,
        text: shareText,
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({
        title: "Character Summary Copied",
        description: "Character summary has been copied to clipboard!",
      });
    }
  };



  const handleDeleteCharacter = async () => {
    if (!selectedCharacter) return;

    try {
      await deleteCharacter.mutateAsync(selectedCharacter.id);
      
      // Select next available character or null
      if (characters && characters.length > 1) {
        const remainingCharacters = characters.filter(c => c.id !== selectedCharacter.id);
        onCharacterChange(remainingCharacters[0]);
      } else {
        onCharacterChange(null as any);
      }
      
      setShowDeleteConfirm(false);
      toast({
        title: "Character Deleted",
        description: `${selectedCharacter.name} has been permanently deleted.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete character. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Randomly select background image
  const backgroundImages = [demplarBg1, demplarBg2];
  const selectedBg = backgroundImages[Math.floor(Math.random() * backgroundImages.length)];

  return (
    <header 
      className="relative text-white shadow-2xl overflow-hidden"
      style={{
        backgroundImage: `url(${selectedBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Overlay for better text readability */}
      <div className="absolute inset-0 bg-black/40"></div>
      <div className="relative container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <i className="fas fa-dragon text-fantasy-gold text-4xl drop-shadow-lg"></i>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-fantasy-gold rounded-full animate-pulse"></div>
            </div>
            <div>
              <h1 className="font-fantasy text-3xl md:text-4xl font-bold bg-gradient-to-r from-fantasy-gold to-yellow-300 bg-clip-text text-transparent">
                Demplar Character Manager
              </h1>
              <p className="text-sm opacity-80 font-medium">Your Gateway to the Demplarverse</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Character Selection Dropdown */}
            {characters && characters.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="bg-black/20 border-white/20 text-white hover:bg-black/30 hover:border-white/40"
                  >
                    {selectedCharacter ? selectedCharacter.name : "Select Character"}
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white border border-gray-200 shadow-lg">
                  <DropdownMenuItem
                    onClick={() => setIsCreateDialogOpen(true)}
                    className="flex items-center space-x-3 px-3 py-2 hover:bg-gray-50 cursor-pointer border-b border-gray-100"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center text-white text-sm font-bold">
                        +
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Create New Character</div>
                        <div className="text-sm text-gray-500">Add a new character</div>
                      </div>
                    </div>
                  </DropdownMenuItem>
                  {characters.map((character) => (
                    <DropdownMenuItem
                      key={character.id}
                      onClick={() => onCharacterChange(character)}
                      className="flex items-center space-x-3 px-3 py-2 hover:bg-gray-50 cursor-pointer"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold">
                          {character.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{character.name}</div>
                          <div className="text-sm text-gray-500">{character.className}</div>
                        </div>
                      </div>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {selectedCharacter && (
              <>
                <Button
                  onClick={handleShare}
                  className="bg-fantasy-gold text-fantasy-deep hover:bg-yellow-300 shadow-lg font-medium"
                >
                  <i className="fas fa-share-alt mr-2"></i>
                  Share Character
                </Button>
                
                <Button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="bg-red-600 text-white hover:bg-red-700 shadow-lg font-medium"
                >
                  <i className="fas fa-trash mr-2"></i>
                  Delete
                </Button>
              </>
            )}
            
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-fantasy-purple hover:bg-purple-600 shadow-lg font-medium">
                  <i className="fas fa-plus mr-2"></i>
                  New Character
                </Button>
              </DialogTrigger>
              
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="font-fantasy text-fantasy-deep">Create New Character</DialogTitle>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Character Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter character name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="playerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Twitter Handle</FormLabel>
                            <FormControl>
                              <Input placeholder="@username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="className"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Class/Role</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="e.g., Shadow Weaver, Dragon Knight, Void Merchant..."
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="faction"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Faction (Optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Silver Arrows" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="avatarUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Character Card Image URL</FormLabel>
                          <FormControl>
                            <div className="flex gap-2">
                              <Input 
                                placeholder="e.g., https://knightsofdegen.netlify.app/images/..."
                                {...field}
                                value={field.value || ""}
                              />
                              <Button
                                type="button"
                                variant="outline"
                                onClick={() => setIsAvatarBrowserOpen(true)}
                                className="whitespace-nowrap"
                              >
                                <i className="fas fa-search mr-2"></i>
                                Browse Knights
                              </Button>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="backstory"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Backstory</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Share your character's origin story..."
                              rows={4}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="notoriety"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notoriety</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select alignment" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="lawful-good">Lawful Good</SelectItem>
                                <SelectItem value="neutral-good">Neutral Good</SelectItem>
                                <SelectItem value="chaotic-good">Chaotic Good</SelectItem>
                                <SelectItem value="lawful-neutral">Lawful Neutral</SelectItem>
                                <SelectItem value="true-neutral">True Neutral</SelectItem>
                                <SelectItem value="chaotic-neutral">Chaotic Neutral</SelectItem>
                                <SelectItem value="lawful-evil">Lawful Evil</SelectItem>
                                <SelectItem value="neutral-evil">Neutral Evil</SelectItem>
                                <SelectItem value="chaotic-evil">Chaotic Evil</SelectItem>
                                <SelectItem value="unknown">Unknown</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end space-x-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsCreateDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createCharacter.isPending}>
                        {createCharacter.isPending ? "Creating..." : "Create Character"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        {/* Selected Character Display */}
        {selectedCharacter && (
          <div className="border-t border-white/20 pt-6">
            <div className="flex items-center space-x-6">
              {/* Character Avatar */}
              <div className="flex-shrink-0">
                {selectedCharacter.avatarUrl ? (
                  <img 
                    src={selectedCharacter.avatarUrl} 
                    alt={selectedCharacter.name}
                    className="w-20 h-20 rounded-xl object-cover border-2 border-fantasy-gold shadow-lg"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      target.nextElementSibling?.classList.remove('hidden');
                    }}
                  />
                ) : null}
                <div className={`w-20 h-20 bg-fantasy-gold/20 rounded-xl border-2 border-fantasy-gold flex items-center justify-center ${selectedCharacter.avatarUrl ? 'hidden' : ''}`}>
                  <i className="fas fa-user text-fantasy-gold text-2xl"></i>
                </div>
              </div>
              
              {/* Character Info */}
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h2 className="text-2xl font-fantasy font-bold text-fantasy-gold">{selectedCharacter.name}</h2>
                  <div className="px-3 py-1 bg-fantasy-purple/80 rounded-full text-sm font-medium">
                    Level {selectedCharacter.level}
                  </div>
                </div>
                <div className="flex items-center space-x-4 text-sm opacity-90">
                  <span><i className="fas fa-shield mr-1"></i>{selectedCharacter.className}</span>
                  {selectedCharacter.faction && (
                    <span><i className="fas fa-flag mr-1"></i>{selectedCharacter.faction}</span>
                  )}
                  {formatTwitterHandle(selectedCharacter.playerName) ? (
                    <a
                      href={formatTwitterHandle(selectedCharacter.playerName)!.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-fantasy-gold transition-colors"
                    >
                      <i className="fas fa-user mr-1"></i>{formatTwitterHandle(selectedCharacter.playerName)!.display}
                    </a>
                  ) : (
                    <span><i className="fas fa-user mr-1"></i>{selectedCharacter.playerName || "No handle set"}</span>
                  )}
                </div>
                
                {/* XP Progress Bar */}
                <div className="mt-3 max-w-md">
                  <div className="flex justify-between text-xs mb-1">
                    <span>XP: {selectedCharacter.currentXP}</span>
                    <span>Next Level: {selectedCharacter.nextLevelXP}</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div 
                      className="bg-fantasy-gold h-2 rounded-full transition-all" 
                      style={{ width: `${Math.min((selectedCharacter.currentXP / selectedCharacter.nextLevelXP) * 100, 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
              
              {/* Quick Stats */}
              <div className="hidden md:flex flex-col space-y-2 text-right text-sm">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-coins text-fantasy-gold"></i>
                  <span>{selectedCharacter.gold} Gold</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="fas fa-backpack text-fantasy-gold"></i>
                  <span>{(selectedCharacter.inventory || []).length + (selectedCharacter.equipment || []).length} Items</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Knights of Degen Avatar Browser */}
      <KnightAvatarBrowser
        isOpen={isAvatarBrowserOpen}
        onClose={() => setIsAvatarBrowserOpen(false)}
        onSelect={(imageUrl) => {
          form.setValue("avatarUrl", imageUrl);
          setIsAvatarBrowserOpen(false);
        }}
      />

      {/* Delete Character Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Character</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-gray-600">
              Are you sure you want to permanently delete <strong>{selectedCharacter?.name}</strong>? 
              This action cannot be undone and will remove all character data including stats, inventory, and session logs.
            </p>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleDeleteCharacter}
                className="bg-red-600 text-white hover:bg-red-700"
                disabled={deleteCharacter.isPending}
              >
                {deleteCharacter.isPending ? "Deleting..." : "Delete Character"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}
