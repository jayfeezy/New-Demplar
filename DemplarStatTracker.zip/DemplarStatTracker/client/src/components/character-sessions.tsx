import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useCreateSessionLog, useUpdateSessionLog, useDeleteSessionLog } from "@/hooks/use-characters";
import { useToast } from "@/hooks/use-toast";
import { insertSessionLogSchema, type Character, type SessionLog } from "@shared/schema";
import type { z } from "zod";

const sessionFormSchema = insertSessionLogSchema.extend({
  title: insertSessionLogSchema.shape.title.min(1, "Session title is required"),
  description: insertSessionLogSchema.shape.description.min(1, "Session description is required"),
});

type SessionFormData = z.infer<typeof sessionFormSchema>;

interface CharacterSessionsProps {
  character: Character | null;
}

export default function CharacterSessions({ character }: CharacterSessionsProps) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<SessionLog | null>(null);
  const { toast } = useToast();
  
  const createSessionLog = useCreateSessionLog();
  const updateSessionLog = useUpdateSessionLog();
  const deleteSessionLog = useDeleteSessionLog();

  const { data: sessionLogs = [], isLoading } = useQuery({
    queryKey: [`/api/characters/${character?.id}/sessions`],
    enabled: !!character?.id,
  });

  const form = useForm<SessionFormData>({
    resolver: zodResolver(sessionFormSchema),
    defaultValues: {
      characterId: character?.id || 0,
      title: "",
      description: "",
      xpGained: 0,
      duration: "",
      tags: [],
      sessionDate: new Date().toISOString().split('T')[0],
    },
  });

  const onSubmit = async (data: SessionFormData) => {
    if (!character) return;

    try {
      if (editingSession) {
        await updateSessionLog.mutateAsync({
          id: editingSession.id,
          updates: data,
        });
        toast({
          title: "Session Updated",
          description: "Session log has been successfully updated!",
        });
        setEditingSession(null);
      } else {
        await createSessionLog.mutateAsync({
          ...data,
          characterId: character.id,
          tags: data.tags || [],
        });
        toast({
          title: "Session Added",
          description: "Session log has been successfully created!",
        });
      }
      
      setIsCreateDialogOpen(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save session log. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (session: SessionLog) => {
    setEditingSession(session);
    form.reset({
      characterId: session.characterId,
      title: session.title,
      description: session.description,
      xpGained: session.xpGained,
      duration: session.duration || "",
      tags: session.tags,
      sessionDate: session.sessionDate,
    });
    setIsCreateDialogOpen(true);
  };

  const handleDelete = async (sessionId: number) => {
    if (!confirm("Are you sure you want to delete this session log?")) return;

    try {
      await deleteSessionLog.mutateAsync(sessionId);
      toast({
        title: "Session Deleted",
        description: "Session log has been successfully deleted!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete session log. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (xp: number) => {
    if (xp >= 150) return "bg-green-500";
    if (xp >= 100) return "bg-blue-500";
    return "bg-yellow-500";
  };

  const getTagColor = (tag: string) => {
    const colors = {
      combat: "bg-red-100 text-red-800",
      puzzle: "bg-yellow-100 text-yellow-800",
      social: "bg-green-100 text-green-800",
      exploration: "bg-blue-100 text-blue-800",
      quest: "bg-purple-100 text-purple-800",
    };
    return colors[tag.toLowerCase() as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  if (!character) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center text-gray-500">
          <i className="fas fa-scroll text-4xl mb-4"></i>
          <p>No character selected.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Session Log Card */}
      <div className="lg:col-span-2">
        <Card className="bg-white rounded-xl shadow-lg border border-gray-200">
          <CardHeader>
            <CardTitle className="text-xl font-fantasy font-bold text-fantasy-deep flex items-center justify-between">
              <div className="flex items-center">
                <i className="fas fa-book-open mr-3 text-fantasy-gold"></i>
                Session History
              </div>
              
              <Dialog open={isCreateDialogOpen} onOpenChange={(open) => {
                setIsCreateDialogOpen(open);
                if (!open) {
                  setEditingSession(null);
                  form.reset();
                }
              }}>
                <DialogTrigger asChild>
                  <Button className="bg-fantasy-purple text-white hover:bg-purple-600 text-sm">
                    <i className="fas fa-plus mr-2"></i>
                    Add Session
                  </Button>
                </DialogTrigger>
                
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="font-fantasy text-fantasy-deep">
                      {editingSession ? "Edit Session Log" : "Add Session Log"}
                    </DialogTitle>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Session Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., The Crystal Caverns" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="sessionDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Session Date</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Duration</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., 3h 15m" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="xpGained"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>XP Gained</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="0"
                                  {...field}
                                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Session Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                rows={4}
                                placeholder="Describe what happened in this session..."
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end space-x-2 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsCreateDialogOpen(false)}
                        >
                          Cancel
                        </Button>
                        <Button type="submit" disabled={createSessionLog.isPending || updateSessionLog.isPending}>
                          {editingSession ? "Update Session" : "Add Session"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardTitle>
          </CardHeader>
          
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-3"></div>
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                  </div>
                ))}
              </div>
            ) : sessionLogs.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <i className="fas fa-journal-whills text-3xl mb-2"></i>
                <p>No session logs yet</p>
                <p className="text-sm">Start documenting your adventures!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sessionLogs.map((session: SessionLog) => (
                  <div key={session.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 ${getStatusColor(session.xpGained)} rounded-full`}></div>
                        <div>
                          <div className="font-medium">{session.title}</div>
                          <div className="text-sm text-gray-500">
                            {new Date(session.sessionDate).toLocaleDateString()} 
                            {session.duration && ` • ${session.duration}`}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-green-100 text-green-800">
                          +{session.xpGained} XP
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(session)}
                          className="text-blue-500 hover:text-blue-700"
                        >
                          <i className="fas fa-edit"></i>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(session.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <i className="fas fa-trash"></i>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-700 mb-2">{session.description}</div>
                    
                    {session.tags && session.tags.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {session.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className={getTagColor(tag)}>
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Notes Card */}
      <Card className="bg-white rounded-xl shadow-lg border border-gray-200">
        <CardHeader>
          <CardTitle className="text-xl font-fantasy font-bold text-fantasy-deep flex items-center">
            <i className="fas fa-sticky-note mr-3 text-fantasy-gold"></i>
            Quick Notes
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-4">
            <div className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Active Quests</span>
                <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-700 text-xs">
                  <i className="fas fa-edit"></i>
                </Button>
              </div>
              <Textarea
                rows={3}
                placeholder="Track your active quests..."
                className="text-sm border-0 p-0 resize-none focus-visible:ring-0"
                defaultValue="• Find the missing crystal fragments (2/5 found)&#10;• Deliver message to Captain Theron&#10;• Investigate the haunted forest reports"
              />
            </div>
            
            <div className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Important NPCs</span>
                <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-700 text-xs">
                  <i className="fas fa-edit"></i>
                </Button>
              </div>
              <Textarea
                rows={3}
                placeholder="Remember important characters..."
                className="text-sm border-0 p-0 resize-none focus-visible:ring-0"
                defaultValue="• Captain Theron (Silver Arrows leader)&#10;• Sage Mirielle (faction advisor)&#10;• Elder Moonwhisper (grandmother)&#10;• Merchant Gareth (guild contact)"
              />
            </div>
            
            <div className="border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Session Ideas</span>
                <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-700 text-xs">
                  <i className="fas fa-edit"></i>
                </Button>
              </div>
              <Textarea
                rows={4}
                placeholder="Jot down ideas for future sessions..."
                className="text-sm border-0 p-0 resize-none focus-visible:ring-0"
                defaultValue="Want to explore the connection between the crystal fragments and ancient elven magic. Maybe visit the old watchtower mentioned by Sage Mirielle?"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
