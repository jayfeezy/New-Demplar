import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCharacters } from "@/hooks/use-characters";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export default function CharacterAdmin() {
  const { data: characters = [], isLoading } = useCharacters();
  const { user } = useAuth();
  const { toast } = useToast();
  const [importing, setImporting] = useState(false);
  const [cleaning, setCleaning] = useState(false);
  const [discovering, setDiscovering] = useState(false);
  const [comprehensiveDiscovering, setComprehensiveDiscovering] = useState(false);
  const [realScraping, setRealScraping] = useState(false);

  const handleImportKnights = async () => {
    setImporting(true);
    try {
      const response = await fetch("/api/import-knights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Knights Import Completed",
          description: `Imported ${data.imported} verified Knights profiles with authentic card data. Skipped ${data.skipped} existing characters.`,
        });
        
        // Refresh the characters list
        queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      } else {
        throw new Error(data.error || "Import failed");
      }
    } catch (error) {
      console.error("Import error:", error);
      toast({
        title: "Import Failed",
        description: "Failed to import Knights of Degen profiles. Please try again.",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
    }
  };

  const handleAPIDiscovery = async () => {
    setRealScraping(true);
    try {
      const response = await fetch("/api/discover-knights-api", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Authentic Data Loaded",
          description: `Found ${data.characters?.length || 0} authentic Knights characters with verified image URLs`,
        });
        console.log("AUTHENTIC KNIGHTS DATA:");
        console.log(`Method used: ${data.method}`);
        console.log(`Total characters found: ${data.totalFound}`);
        console.log("All authentic characters:", data.characters);
        
        if (data.characters && data.characters.length > 0) {
          console.log("VERIFIED CHARACTER DATA:");
          data.characters.forEach((char: any) => {
            console.log(`✓ ${char.name} (${char.className}, Level ${char.level})`);
            console.log(`  Image: ${char.image}`);
            console.log(`  Player: ${char.playerName}`);
          });
        }
      } else {
        toast({
          title: "Extraction Complete",
          description: `Found ${data.totalFound || 0} Knights characters (${data.enrichedCount || 0} with full data, ${data.discoveredCount || 0} discovered)`,
        });
        console.log("EXTRACTION RESULTS:");
        console.log(`Total found: ${data.totalFound}`);
        console.log(`Enriched: ${data.enrichedCount}`);
        console.log(`Discovered: ${data.discoveredCount}`);
      }
    } catch (error) {
      console.error("Authentic data loading error:", error);
      toast({
        title: "Loading Failed",
        description: "Failed to load authentic Knights character data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setRealScraping(false);
    }
  };

  const handleComprehensiveDiscovery = async () => {
    setComprehensiveDiscovering(true);
    try {
      const response = await fetch("/api/comprehensive-knights-discovery", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Comprehensive Discovery Complete",
          description: `Found ${data.workingUrls?.length || 0} authentic Knights character image URLs out of ${data.totalTested} tested.`,
        });
        console.log("COMPREHENSIVE DISCOVERY RESULTS:");
        console.log(`Total URLs tested: ${data.totalTested}`);
        console.log(`Working URLs found: ${data.workingUrls?.length || 0}`);
        console.log("All working URLs:", data.workingUrls);
      } else {
        throw new Error(data.error || "Comprehensive discovery failed");
      }
    } catch (error) {
      console.error("Comprehensive discovery error:", error);
      toast({
        title: "Discovery Failed",
        description: "Failed to run comprehensive Knights URL discovery. Please try again.",
        variant: "destructive",
      });
    } finally {
      setComprehensiveDiscovering(false);
    }
  };

  const handleAutoDiscoverKnights = async () => {
    setDiscovering(true);
    try {
      const response = await fetch("/api/auto-discover-knights", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Auto-Discovery Complete",
          description: `Found ${data.validatedUrls?.length || 0} working URLs out of ${data.discoveredUrls?.length || 0} tested. Check console for details.`,
        });
        console.log("Discovered Knights URLs:", data.discoveredUrls);
        console.log("Validated working URLs:", data.validatedUrls);
        
        if (data.validatedUrls && data.validatedUrls.length > data.knownWorkingCount) {
          console.log("NEW WORKING URLS FOUND:");
          data.validatedUrls.slice(data.knownWorkingCount).forEach((url: string) => {
            console.log(`✓ ${url}`);
          });
        }
      } else {
        throw new Error(data.error || "Auto-discovery failed");
      }
    } catch (error) {
      console.error("Auto-discovery error:", error);
      toast({
        title: "Auto-Discovery Failed",
        description: "Failed to discover Knights URLs. Please try again.",
        variant: "destructive",
      });
    } finally {
      setDiscovering(false);
    }
  };

  const handleCleanupKnights = async () => {
    setCleaning(true);
    try {
      const response = await fetch("/api/characters/cleanup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Cleanup Completed",
          description: `Deleted ${data.deleted} extra Knights characters.`,
        });
        
        // Refresh the characters list
        queryClient.invalidateQueries({ queryKey: ["/api/characters"] });
      } else {
        throw new Error(data.error || "Cleanup failed");
      }
    } catch (error) {
      console.error("Cleanup error:", error);
      toast({
        title: "Cleanup Failed",
        description: "Failed to delete extra characters. Please try again.",
        variant: "destructive",
      });
    } finally {
      setCleaning(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          Loading admin panel...
        </CardContent>
      </Card>
    );
  }

  // Check if user has master privileges
  if (!user || user.role !== "master") {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">Access denied. Master privileges required.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-fantasy-gold">
            Character Administration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Manage all characters in the Demplar system. Only accessible to Game Masters.
          </p>
          
          <div className="grid gap-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Total Characters</h3>
                <p className="text-sm text-muted-foreground">Active characters in the system</p>
              </div>
              <Badge variant="outline" className="text-lg px-3 py-1">
                {characters.length}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Complete Knights Extraction</h3>
                <p className="text-sm text-muted-foreground">Extract all Knights of Degen characters from knightsofdegen.netlify.app using systematic discovery and verified data</p>
              </div>
              <Button 
                onClick={handleAPIDiscovery}
                disabled={realScraping || comprehensiveDiscovering || discovering || importing || cleaning}
                className="bg-green-600 hover:bg-green-700"
              >
                {realScraping ? "Extracting All..." : "Extract All Knights"}
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Comprehensive Discovery</h3>
                <p className="text-sm text-muted-foreground">Systematic URL pattern testing (fallback method - tests 500+ combinations)</p>
              </div>
              <Button 
                onClick={handleComprehensiveDiscovery}
                disabled={comprehensiveDiscovering || discovering || importing || cleaning || realScraping}
                className="bg-orange-600 hover:bg-orange-700"
              >
                {comprehensiveDiscovering ? "Running Discovery..." : "Pattern Testing"}
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Quick URL Discovery</h3>
                <p className="text-sm text-muted-foreground">Fast discovery using known patterns and variations (tests 100 combinations)</p>
              </div>
              <Button 
                onClick={handleAutoDiscoverKnights}
                disabled={discovering || importing || cleaning || comprehensiveDiscovering}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {discovering ? "Discovering..." : "Quick Extract"}
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Knights of Degen Import</h3>
                <p className="text-sm text-muted-foreground">Import all Knights of Degen character profiles with verified images</p>
              </div>
              <div className="flex gap-2">
                <Button 
                  onClick={handleImportKnights}
                  disabled={importing || cleaning || discovering}
                  className="bg-fantasy-purple hover:bg-fantasy-purple/90"
                >
                  {importing ? "Importing..." : "Import Knights"}
                </Button>
                <Button 
                  onClick={handleCleanupKnights}
                  disabled={importing || cleaning || discovering}
                  variant="outline"
                  className="border-red-500 text-red-500 hover:bg-red-50"
                >
                  {cleaning ? "Cleaning..." : "Cleanup Extras"}
                </Button>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">Database Management</h3>
                <p className="text-sm text-muted-foreground">Advanced database operations</p>
              </div>
              <Button variant="outline" disabled>
                Coming Soon
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-semibold">System Logs</h3>
                <p className="text-sm text-muted-foreground">View system activity logs</p>
              </div>
              <Button variant="outline" disabled>
                View Logs
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Quick Character Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {characters.map((character) => (
              <div key={character.id} className="flex items-center justify-between p-3 border rounded">
                <div className="flex items-center gap-3">
                  <div>
                    <h4 className="font-medium">{character.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      Level {character.level} {character.className}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    {character.playerName || 'No Player'}
                  </Badge>
                  {character.duelistRank && (
                    <Badge variant="secondary">
                      Rank {character.duelistRank}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}