import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useUpdateCharacter } from "@/hooks/use-characters";
import { useToast } from "@/hooks/use-toast";
import { updateCharacterSchema, type Character } from "@shared/schema";
import KnightAvatarBrowser from "./knight-avatar-browser";
import type { z } from "zod";

const profileFormSchema = updateCharacterSchema.pick({
  name: true,
  className: true,
  faction: true,
  backstory: true,
  avatarUrl: true,
  notoriety: true,
});

type ProfileFormData = z.infer<typeof profileFormSchema>;

interface CharacterProfileProps {
  character: Character | null;
  onCharacterUpdate: (character: Character) => void;
}

export default function CharacterProfile({ character, onCharacterUpdate }: CharacterProfileProps) {
  const updateCharacter = useUpdateCharacter();
  const { toast } = useToast();
  const [showAvatarBrowser, setShowAvatarBrowser] = useState(false);

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: character?.name || "",
      className: character?.className || "",
      faction: character?.faction || "",
      backstory: character?.backstory || "",
      avatarUrl: character?.avatarUrl || "",
      notoriety: character?.notoriety || "unknown",
    },
  });

  // Update form when character changes
  if (character) {
    const currentValues = form.getValues();
    if (currentValues.name !== character.name) {
      form.reset({
        name: character.name,
        className: character.className,
        faction: character.faction || "",
        backstory: character.backstory || "",
        avatarUrl: character.avatarUrl || "",
        notoriety: character.notoriety || "unknown",
      });
    }
  }

  const onSubmit = async (data: ProfileFormData) => {
    if (!character) return;

    try {
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: data,
      });
      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
        toast({
          title: "Profile Updated",
          description: "Character profile has been successfully updated!",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update character profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAvatarSelect = (imageUrl: string) => {
    form.setValue("avatarUrl", imageUrl);
    setShowAvatarBrowser(false);
    toast({
      title: "Avatar Updated",
      description: "Character avatar has been updated. Click Save to apply changes.",
    });
  };

  const handleManualAvatarUrl = () => {
    const url = prompt("Enter the full URL of a character image:");
    if (url && url.trim()) {
      form.setValue("avatarUrl", url.trim());
      toast({
        title: "Avatar Updated",
        description: "Character avatar has been updated. Click Save to apply changes.",
      });
    }
  };

  const handleQuickAction = (action: string) => {
    // These would open respective dialogs/forms
    toast({
      title: "Quick Action",
      description: `${action} feature coming soon!`,
    });
  };

  if (!character) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center text-gray-500">
          <i className="fas fa-user-plus text-4xl mb-4"></i>
          <p>No character selected. Create a new character to get started!</p>
        </div>
      </div>
    );
  }

  return (
    <>
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Character Profile Card */}
      <Card className="bg-white rounded-xl shadow-lg border border-gray-200">
        <CardHeader>
          <CardTitle className="text-2xl font-fantasy font-bold text-fantasy-deep flex items-center">
            <i className="fas fa-user-circle mr-3 text-fantasy-gold"></i>
            Character Profile
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Character Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="className"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Class/Role</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Shadow Weaver, Dragon Knight, Void Merchant..."
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="faction"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Faction</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Silver Arrows" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="backstory"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Backstory</FormLabel>
                    <FormControl>
                      <Textarea 
                        rows={4}
                        placeholder="Share your character's origin story..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Avatar Section */}
              <div className="space-y-3">
                <FormLabel>Character Avatar</FormLabel>
                <div className="flex items-center gap-4">
                  {form.watch("avatarUrl") && (
                    <div className="relative">
                      <img 
                        src={`/api/proxy-image?url=${encodeURIComponent(form.watch("avatarUrl"))}`}
                        alt="Character Avatar" 
                        className="w-16 h-16 rounded-full object-cover border-2 border-fantasy-gold"
                        onLoad={(e) => {
                          console.log("Image loaded successfully:", form.watch("avatarUrl"));
                        }}
                        onError={(e) => {
                          console.error("Image failed to load:", form.watch("avatarUrl"));
                          (e.target as HTMLImageElement).src = "https://via.placeholder.com/64x64/cccccc/666666?text=No+Image";
                        }}
                      />
                    </div>
                  )}
                  <div className="flex flex-col gap-2">
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAvatarBrowser(true)}
                        className="text-fantasy-purple border-fantasy-purple hover:bg-fantasy-purple hover:text-white"
                      >
                        <i className="fas fa-images mr-2"></i>
                        Browse Knights
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleManualAvatarUrl}
                        className="text-fantasy-blue border-fantasy-blue hover:bg-fantasy-blue hover:text-white"
                      >
                        <i className="fas fa-link mr-2"></i>
                        Custom URL
                      </Button>
                    </div>
                    {form.watch("avatarUrl") && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => form.setValue("avatarUrl", "")}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 self-start"
                      >
                        <i className="fas fa-times mr-1"></i>
                        Remove Avatar
                      </Button>
                    )}
                  </div>
                </div>
                {form.watch("avatarUrl") && (
                  <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded border break-all">
                    <strong>Current URL:</strong> {form.watch("avatarUrl")}
                  </div>
                )}
              </div>

              <FormField
                control={form.control}
                name="notoriety"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notoriety</FormLabel>
                    <FormControl>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select alignment" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lawful-good">Lawful Good</SelectItem>
                          <SelectItem value="neutral-good">Neutral Good</SelectItem>
                          <SelectItem value="chaotic-good">Chaotic Good</SelectItem>
                          <SelectItem value="lawful-neutral">Lawful Neutral</SelectItem>
                          <SelectItem value="true-neutral">True Neutral</SelectItem>
                          <SelectItem value="chaotic-neutral">Chaotic Neutral</SelectItem>
                          <SelectItem value="lawful-evil">Lawful Evil</SelectItem>
                          <SelectItem value="neutral-evil">Neutral Evil</SelectItem>
                          <SelectItem value="chaotic-evil">Chaotic Evil</SelectItem>
                          <SelectItem value="unknown">Unknown</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button type="submit" disabled={updateCharacter.isPending}>
                {updateCharacter.isPending ? "Updating..." : "Update Profile"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Quick Actions Card */}
      <Card className="bg-white rounded-xl shadow-lg border border-gray-200">
        <CardHeader>
          <CardTitle className="text-xl font-fantasy font-bold text-fantasy-deep flex items-center">
            <i className="fas fa-bolt mr-3 text-fantasy-gold"></i>
            Quick Actions
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Button
              variant="outline"
              className="bg-green-50 border-green-200 hover:bg-green-100 text-center p-4 h-auto flex flex-col"
              onClick={() => handleQuickAction("Add XP")}
            >
              <i className="fas fa-plus-circle text-green-600 text-2xl mb-2"></i>
              <span className="text-sm font-medium text-green-700">Add XP</span>
            </Button>
            
            <Button
              variant="outline"
              className="bg-blue-50 border-blue-200 hover:bg-blue-100 text-center p-4 h-auto flex flex-col"
              onClick={() => handleQuickAction("Level Up")}
            >
              <i className="fas fa-level-up-alt text-blue-600 text-2xl mb-2"></i>
              <span className="text-sm font-medium text-blue-700">Level Up</span>
            </Button>
            
            <Button
              variant="outline"
              className="bg-purple-50 border-purple-200 hover:bg-purple-100 text-center p-4 h-auto flex flex-col"
              onClick={() => handleQuickAction("Add Item")}
            >
              <i className="fas fa-magic text-purple-600 text-2xl mb-2"></i>
              <span className="text-sm font-medium text-purple-700">Add Item</span>
            </Button>
            
            <Button
              variant="outline"
              className="bg-yellow-50 border-yellow-200 hover:bg-yellow-100 text-center p-4 h-auto flex flex-col"
              onClick={() => handleQuickAction("Session Note")}
            >
              <i className="fas fa-feather-alt text-yellow-600 text-2xl mb-2"></i>
              <span className="text-sm font-medium text-yellow-700">Session Note</span>
            </Button>
          </div>
          
          <div className="p-4 bg-fantasy-deep rounded-lg text-white">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm opacity-90">Next Game Night</span>
              <i className="fas fa-calendar-alt text-fantasy-gold"></i>
            </div>
            <div className="font-medium">Saturday, 8:00 PM EST</div>
            <div className="text-sm opacity-75">Follow @demplarofficial for updates</div>
          </div>
        </CardContent>
      </Card>
    </div>
    
    {/* Knights of Degen Avatar Browser */}
    <KnightAvatarBrowser
      isOpen={showAvatarBrowser}
      onClose={() => setShowAvatarBrowser(false)}
      onSelect={handleAvatarSelect}
    />
    </>
  );
}
