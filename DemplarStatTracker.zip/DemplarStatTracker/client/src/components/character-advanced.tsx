import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import type { Character } from "@shared/schema";

interface CharacterAdvancedProps {
  character: Character | null;
  onCharacterUpdate: (character: Character) => void;
}

export default function CharacterAdvanced({ character, onCharacterUpdate }: CharacterAdvancedProps) {
  const [isEditing, setIsEditing] = useState(false);

  if (!character) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-muted-foreground">
          Select a character to view advanced details
        </CardContent>
      </Card>
    );
  }

  const getRankColor = (rank: string) => {
    switch (rank?.toUpperCase()) {
      case 'S': return 'bg-red-100 text-red-800';
      case 'A': return 'bg-orange-100 text-orange-800';
      case 'B': return 'bg-yellow-100 text-yellow-800';
      case 'C': return 'bg-green-100 text-green-800';
      case 'D': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getBattleResultColor = (result: string) => {
    switch (result) {
      case 'Won': return 'text-green-600';
      case 'Lost': return 'text-red-600';
      case 'Fled': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-bold text-fantasy-gold">
            Advanced Character Details
          </CardTitle>
          <Button
            variant={isEditing ? "destructive" : "outline"}
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
          >
            {isEditing ? "Cancel" : "Edit"}
          </Button>
        </CardHeader>
      </Card>

      <Tabs defaultValue="combat" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="combat">Combat</TabsTrigger>
          <TabsTrigger value="abilities">Abilities</TabsTrigger>
          <TabsTrigger value="items">Items</TabsTrigger>
          <TabsTrigger value="quests">Quests</TabsTrigger>
          <TabsTrigger value="status">Status</TabsTrigger>
          <TabsTrigger value="lore">Lore</TabsTrigger>
        </TabsList>

        {/* Combat Tab */}
        <TabsContent value="combat" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Duelist Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Duelist Ranking</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Rank:</span>
                  <Badge className={getRankColor(character.duelistRank || 'N/A')}>
                    {character.duelistRank || 'Unranked'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Points:</span>
                  <span className="font-bold">{character.duelistPoints || 0}</span>
                </div>
              </CardContent>
            </Card>

            {/* Weapon */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Primary Weapon</CardTitle>
              </CardHeader>
              <CardContent>
                {character.weapon ? (
                  <div className="space-y-2">
                    <h4 className="font-bold text-fantasy-gold">{character.weapon.name}</h4>
                    <p className="text-sm text-muted-foreground">{character.weapon.description}</p>
                    <div className="space-y-1">
                      {character.weapon.effects?.map((effect, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {effect}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No weapon equipped</p>
                )}
              </CardContent>
            </Card>

            {/* Support Skill */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Support Skill</CardTitle>
              </CardHeader>
              <CardContent>
                {character.supportSkill ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold">{character.supportSkill.name}</h4>
                      <Badge className={getRankColor(character.supportSkill.level)}>
                        Level {character.supportSkill.level}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{character.supportSkill.description}</p>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No support skill</p>
                )}
              </CardContent>
            </Card>

            {/* Traits */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Character Traits</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {character.traits && character.traits.length > 0 ? (
                    character.traits.map((trait, index) => (
                      <Badge key={index} variant="secondary">
                        {trait}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-muted-foreground">No traits defined</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Abilities Tab */}
        <TabsContent value="abilities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Combat Abilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {character.abilities && character.abilities.length > 0 ? (
                  character.abilities.map((ability, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <h4 className="font-bold text-fantasy-gold">{ability.name}</h4>
                      <p className="text-sm text-muted-foreground">{ability.description}</p>
                      <div className="flex flex-wrap gap-1">
                        {ability.effects?.map((effect, effectIndex) => (
                          <Badge key={effectIndex} variant="outline" className="text-xs">
                            {effect}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground">No abilities learned</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {character.skills && Object.keys(character.skills).length > 0 ? (
                  Object.entries(character.skills).map(([skill, description]) => (
                    <div key={skill} className="flex items-center justify-between p-2 border rounded">
                      <span className="font-medium">{skill}</span>
                      <span className="text-sm text-muted-foreground">{description}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground">No skills developed</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Items Tab */}
        <TabsContent value="items" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Event Items */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Event Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {character.eventItems && character.eventItems.length > 0 ? (
                    character.eventItems.map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <span className="font-medium">{item.name}</span>
                          {item.description && (
                            <p className="text-xs text-muted-foreground">{item.description}</p>
                          )}
                        </div>
                        <Badge variant="outline">x{item.quantity}</Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground">No event items</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quest Items */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-fantasy-gold">Quest Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {character.questItems && character.questItems.length > 0 ? (
                    character.questItems.map((item, index) => (
                      <div key={index} className="border rounded p-3 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{item.name}</span>
                          <Badge variant="outline" className="text-xs">{item.source}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-muted-foreground">No quest items</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Quests Tab */}
        <TabsContent value="quests" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Active Quests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {character.activeQuests && character.activeQuests.length > 0 ? (
                  character.activeQuests.map((quest, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <h4 className="font-bold">{quest.name}</h4>
                      <p className="text-sm text-muted-foreground">{quest.description}</p>
                      <div className="flex gap-2">
                        {quest.location && (
                          <Badge variant="outline">
                            <i className="fas fa-map-marker-alt mr-1"></i>
                            {quest.location}
                          </Badge>
                        )}
                        {quest.questGiver && (
                          <Badge variant="outline">
                            <i className="fas fa-user mr-1"></i>
                            {quest.questGiver}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground">No active quests</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Status Tab */}
        <TabsContent value="status" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Status Effects & Buffs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {character.statusEffects && character.statusEffects.length > 0 ? (
                  character.statusEffects.map((effect, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-fantasy-gold">{effect.name}</h4>
                        {effect.duration && (
                          <Badge variant="outline">{effect.duration}</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{effect.description}</p>
                      <div className="flex flex-wrap gap-1">
                        {effect.effects?.map((eff, effIndex) => (
                          <Badge key={effIndex} variant="secondary" className="text-xs">
                            {eff}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground">No active status effects</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Lore Tab */}
        <TabsContent value="lore" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-fantasy-gold">Exploration & Lore</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {character.loreEntries && character.loreEntries.length > 0 ? (
                  character.loreEntries.map((entry, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-3">
                      <h4 className="font-bold text-fantasy-gold">
                        <i className="fas fa-map-marker-alt mr-2"></i>
                        {entry.location}
                      </h4>
                      
                      {/* Events */}
                      {entry.events && entry.events.length > 0 && (
                        <div>
                          <h5 className="font-semibold mb-2">Events:</h5>
                          <ul className="list-disc list-inside space-y-1">
                            {entry.events.map((event, eventIndex) => (
                              <li key={eventIndex} className="text-sm">{event}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* NPCs */}
                      {entry.npcsEncountered && entry.npcsEncountered.length > 0 && (
                        <div>
                          <h5 className="font-semibold mb-2">NPCs Encountered:</h5>
                          <div className="flex flex-wrap gap-1">
                            {entry.npcsEncountered.map((npc, npcIndex) => (
                              <Badge key={npcIndex} variant="outline">
                                <i className="fas fa-user mr-1"></i>
                                {npc}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Battles */}
                      {entry.battles && entry.battles.length > 0 && (
                        <div>
                          <h5 className="font-semibold mb-2">Battles:</h5>
                          <div className="space-y-2">
                            {entry.battles.map((battle, battleIndex) => (
                              <div key={battleIndex} className="border rounded p-3 space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="font-medium">{battle.enemy}</span>
                                  <Badge 
                                    variant="outline" 
                                    className={getBattleResultColor(battle.result)}
                                  >
                                    {battle.result}
                                  </Badge>
                                </div>
                                {battle.description && (
                                  <p className="text-xs text-muted-foreground">{battle.description}</p>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground">No exploration records</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}