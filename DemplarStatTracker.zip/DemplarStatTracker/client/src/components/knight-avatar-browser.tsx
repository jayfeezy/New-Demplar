import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface KnightImage {
  name: string;
  url: string;
  character: string;
}

interface KnightAvatarBrowserProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (imageUrl: string) => void;
}

export default function KnightAvatarBrowser({ isOpen, onClose, onSelect }: KnightAvatarBrowserProps) {
  const [images, setImages] = useState<KnightImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const loadKnightImages = async () => {
    setLoading(true);
    
    try {
      const response = await fetch("/api/knights-images", {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success && data.images) {
        setImages(data.images);
        toast({
          title: "Images Loaded",
          description: `Found ${data.total} Knights of Degen character images`,
        });
      } else {
        throw new Error(data.error || "Failed to load images");
      }
    } catch (error) {
      console.error("Error loading Knight images:", error);
      setImages([]);
      toast({
        title: "Connection Issue",
        description: "Unable to load character images from Knights of Degen. You can manually enter an image URL.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadKnightImages();
    }
  }, [isOpen]);

  const filteredImages = images.filter(img => {
    return img.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
           img.character.toLowerCase().includes(searchTerm.toLowerCase()) ||
           img.url.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleManualUrl = () => {
    const url = prompt("Enter the full URL of a Knights of Degen character image:");
    if (url && url.trim()) {
      onSelect(url.trim());
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-fantasy-deep">
            Knights of Degen Character Images
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Search character images..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Button 
              onClick={handleManualUrl}
              variant="outline"
              className="whitespace-nowrap"
            >
              Manual URL
            </Button>
            <Button 
              onClick={loadKnightImages}
              variant="outline"
              disabled={loading}
            >
              Refresh
            </Button>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-fantasy-purple mx-auto mb-2"></div>
                <p className="text-gray-600">Loading Knights of Degen character images...</p>
              </div>
            </div>
          )}

          {!loading && filteredImages.length === 0 && (
            <div className="text-center py-8">
              <div className="text-gray-500">
                <i className="fas fa-image text-4xl mb-4"></i>
                <p>No character images found.</p>
                <p className="text-sm mt-2">Try refreshing or use the "Manual URL" button to enter a direct image link.</p>
              </div>
            </div>
          )}

          {!loading && filteredImages.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredImages.map((image, index) => (
                <div
                  key={index}
                  className="border border-gray-200 rounded-lg p-3 hover:border-fantasy-purple transition-colors cursor-pointer hover:shadow-md"
                  onClick={() => {
                    onSelect(image.url);
                    onClose();
                    toast({
                      title: "Image Selected",
                      description: `Selected ${image.name} character image`,
                    });
                  }}
                >
                  <img
                    src={image.url}
                    alt={image.name}
                    className="w-full h-32 object-cover rounded mb-2"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-800 truncate">
                      {image.name}
                    </p>
                    <p className="text-xs text-gray-500 truncate">
                      {image.character}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="text-xs text-gray-500 text-center border-t pt-4">
            Images sourced from: knightsofdegen.netlify.app
            <br />
            Click any image to select it as your character avatar
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}