import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { useCharacters } from "@/hooks/use-characters";
import type { Character } from "@shared/schema";

// Format Twitter handle for display
function formatTwitterHandle(handle: string | null | undefined): { display: string; url: string } | null {
  if (!handle) return null;
  
  const cleanHandle = handle.startsWith('@') ? handle.slice(1) : handle;
  if (!cleanHandle.trim()) return null;
  
  return {
    display: `@${cleanHandle}`,
    url: `https://twitter.com/${cleanHandle}`
  };
}

interface CharacterLookupProps {
  onCharacterSelect: (character: Character) => void;
}

export default function CharacterLookup({ onCharacterSelect }: CharacterLookupProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevelRange, setSelectedLevelRange] = useState("");
  const [selectedNotoriety, setSelectedNotoriety] = useState("");
  
  const { data: characters = [], isLoading } = useCharacters();
  
  const { data: searchResults = [] } = useQuery({
    queryKey: [`/api/characters/search`, searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return characters;
      const response = await fetch(`/api/characters/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: !!searchQuery.trim(),
  });

  const filteredCharacters = searchQuery.trim() ? searchResults : characters;
  
  // Apply level range filter
  const levelFilteredCharacters = selectedLevelRange && selectedLevelRange !== "all"
    ? filteredCharacters.filter((char: Character) => {
        const level = char.level;
        switch (selectedLevelRange) {
          case "1-10": return level >= 1 && level <= 10;
          case "11-20": return level >= 11 && level <= 20;
          case "21-29": return level >= 21 && level <= 29;
          case "30-39": return level >= 30 && level <= 39;
          case "40-49": return level >= 40 && level <= 49;
          case "50+": return level >= 50;
          default: return true;
        }
      })
    : filteredCharacters;

  // Apply notoriety filter
  const finalFilteredCharacters = selectedNotoriety && selectedNotoriety !== "all"
    ? levelFilteredCharacters.filter((char: Character) => char.notoriety === selectedNotoriety)
    : levelFilteredCharacters;

  // Level range options
  const levelRangeOptions = [
    "1-10", "11-20", "21-29", "30-39", "40-49", "50+"
  ];

  // Notoriety options based on D&D alignment system
  const notorietyOptions = [
    "Lawful Good", "Neutral Good", "Chaotic Good", 
    "Lawful Neutral", "True Neutral", "Chaotic Neutral", 
    "Lawful Evil", "Neutral Evil", "Chaotic Evil", "Unknown"
  ];

  const getCharacterIcon = (className: string) => {
    const lowerClass = className.toLowerCase();
    if (lowerClass.includes('ranger') || lowerClass.includes('archer')) return 'fas fa-bow-arrow';
    if (lowerClass.includes('warrior') || lowerClass.includes('fighter')) return 'fas fa-shield';
    if (lowerClass.includes('mage') || lowerClass.includes('wizard')) return 'fas fa-magic';
    if (lowerClass.includes('cleric') || lowerClass.includes('priest')) return 'fas fa-cross';
    if (lowerClass.includes('rogue') || lowerClass.includes('thief')) return 'fas fa-mask';
    return 'fas fa-user';
  };

  const getCharacterTags = (character: Character) => {
    const tags = [];
    
    // Level badge
    tags.push(
      <Badge key="level" variant="outline" className="bg-green-100 text-green-800">
        Level {character.level}
      </Badge>
    );
    
    // Notoriety badge
    if (character.notoriety) {
      const getNotorietyColor = (notoriety: string) => {
        const lower = notoriety.toLowerCase();
        if (lower.includes('good')) return 'bg-green-100 text-green-800';
        if (lower.includes('evil')) return 'bg-red-100 text-red-800';
        if (lower.includes('neutral') || lower.includes('true neutral')) return 'bg-gray-100 text-gray-800';
        if (lower.includes('unknown')) return 'bg-yellow-100 text-yellow-800';
        return 'bg-blue-100 text-blue-800';
      };
      
      tags.push(
        <Badge key="notoriety" variant="outline" className={getNotorietyColor(character.notoriety)}>
          <i className="fas fa-balance-scale mr-1"></i>
          {character.notoriety}
        </Badge>
      );
    }
    
    return tags;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-fantasy-gold">Character Lookup</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-fantasy-gold mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Loading characters...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-bold text-fantasy-gold">Character Lookup</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Controls */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <Input
                placeholder="Search by name, Twitter handle, or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            {(searchQuery || selectedLevelRange || selectedNotoriety) && (
              <Button
                variant="outline"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedLevelRange("");
                  setSelectedNotoriety("");
                }}
                className="whitespace-nowrap"
              >
                Clear All
              </Button>
            )}
          </div>
          
          {/* Filter Row */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="w-full sm:w-48">
              <Select value={selectedLevelRange} onValueChange={setSelectedLevelRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  {levelRangeOptions.map((range) => (
                    <SelectItem key={range} value={range}>
                      Level {range}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full sm:w-48">
              <Select value={selectedNotoriety} onValueChange={setSelectedNotoriety}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by notoriety" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Notoriety</SelectItem>
                  {notorietyOptions.map((notoriety) => (
                    <SelectItem key={notoriety} value={notoriety}>
                      {notoriety}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Character Results */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {finalFilteredCharacters.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchQuery || selectedLevelRange || selectedNotoriety ? "No characters found matching your criteria." : "No characters available."}
            </div>
          ) : (
            finalFilteredCharacters.map((character: Character) => (
              <Card
                key={character.id}
                className="cursor-pointer hover:bg-muted/50 transition-colors border border-fantasy-border hover:border-fantasy-gold/50"
                onClick={() => onCharacterSelect(character)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {/* Avatar */}
                    <div className="relative h-12 w-12 border-2 border-fantasy-gold/20 rounded-full overflow-hidden bg-fantasy-gold/20 flex items-center justify-center">
                      {character.avatarUrl ? (
                        <img 
                          src={`/api/proxy-image?url=${encodeURIComponent(character.avatarUrl)}`}
                          alt={character.name}
                          className="w-full h-full object-cover"
                          onLoad={() => console.log("Avatar loaded:", character.name)}
                          onError={(e) => {
                            console.error("Avatar failed to load:", character.name, character.avatarUrl);
                            (e.target as HTMLElement).style.display = 'none';
                            const fallback = (e.target as HTMLElement).nextElementSibling as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }}
                        />
                      ) : null}
                      <div className="absolute inset-0 flex items-center justify-center text-fantasy-gold font-bold text-sm" style={{display: character.avatarUrl ? 'none' : 'flex'}}>
                        {character.name.substring(0, 2).toUpperCase()}
                      </div>
                    </div>
                    
                    {/* Character Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold text-lg text-fantasy-gold truncate">
                          {character.name}
                        </h3>
                        <div className="flex gap-1 flex-wrap">
                          {getCharacterTags(character)}
                        </div>
                      </div>
                      
                      {/* Player Name / Twitter Handle */}
                      {character.playerName && (
                        <div className="mb-2">
                          <span className="text-sm text-muted-foreground">Twitter Handle: </span>
                          {formatTwitterHandle(character.playerName) ? (
                            <a
                              href={formatTwitterHandle(character.playerName)!.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {formatTwitterHandle(character.playerName)!.display}
                            </a>
                          ) : (
                            <span className="text-sm font-medium">{character.playerName}</span>
                          )}
                        </div>
                      )}
                      
                      {/* XP Progress */}
                      <div className="mb-2">
                        <div className="flex justify-between text-xs text-muted-foreground mb-1">
                          <span>XP Progress</span>
                          <span>{character.currentXP} / {character.nextLevelXP}</span>
                        </div>
                        <Progress 
                          value={(character.currentXP / character.nextLevelXP) * 100} 
                          className="h-2"
                        />
                      </div>
                      
                      {/* Backstory Preview */}
                      {character.backstory && (
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {character.backstory}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}