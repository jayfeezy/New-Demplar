import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { useUpdateCharacter } from "@/hooks/use-characters";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import type { Character } from "@shared/schema";

interface CharacterStatsProps {
  character: Character | null;
  onCharacterUpdate: (character: Character) => void;
}

export default function CharacterStats({ character, onCharacterUpdate }: CharacterStatsProps) {
  const [newStatName, setNewStatName] = useState("");
  const [newStatValue, setNewStatValue] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const updateCharacter = useUpdateCharacter();
  const { toast } = useToast();
  const { isMaster } = useAuth();

  const getRankColor = (rank: string) => {
    switch (rank?.toUpperCase()) {
      case 'S': return 'bg-red-100 text-red-800';
      case 'A': return 'bg-orange-100 text-orange-800';
      case 'B': return 'bg-yellow-100 text-yellow-800';
      case 'C': return 'bg-green-100 text-green-800';
      case 'D': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleUpdateStat = async (statName: keyof Character, value: number | string) => {
    if (!character || !isMaster) return;

    try {
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: { [statName]: value },
      });
      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
        toast({
          title: "Success",
          description: "Character updated successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update character. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateCustomStat = async (statName: string, value: number) => {
    if (!character || !isMaster) return;

    try {
      const updatedCustomStats = { ...character.customStats, [statName]: value };
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: { customStats: updatedCustomStats },
      });
      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update custom stat. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddCustomStat = async () => {
    if (!character || !newStatName.trim() || !newStatValue || !isMaster) return;

    try {
      const updatedCustomStats = { 
        ...character.customStats, 
        [newStatName.trim()]: parseInt(newStatValue) 
      };
      const updatedCharacter = await updateCharacter.mutateAsync({
        id: character.id,
        updates: { customStats: updatedCustomStats },
      });
      if (updatedCharacter) {
        onCharacterUpdate(updatedCharacter);
        setNewStatName("");
        setNewStatValue("");
        toast({
          title: "Custom Stat Added",
          description: `${newStatName.trim()} has been added!`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add custom stat. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!character) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center text-gray-500">
          <i className="fas fa-chart-bar text-4xl mb-4"></i>
          <p>No character selected.</p>
        </div>
      </div>
    );
  }

  const powerProgress = ((character.powerLevel - 1) / 999) * 100;
  const loreProgress = ((character.loreLevel - 1) / 999) * 100;

  const arenaRankings = [
    "N/A", "FF", "EE", "DD", "CC", "BB", "AA", 
    "F", "E", "D", "C", "B", "A", "S", "SS", "SSS"
  ];

  const coreStats = [
    { name: "Strength", key: "strength" as keyof Character, color: "red", icon: "fas fa-dumbbell" },
    { name: "Dexterity", key: "dexterity" as keyof Character, color: "green", icon: "fas fa-running" },
    { name: "Intelligence", key: "intelligence" as keyof Character, color: "blue", icon: "fas fa-brain" },
    { name: "Wisdom", key: "wisdom" as keyof Character, color: "purple", icon: "fas fa-eye" },
    { name: "Constitution", key: "constitution" as keyof Character, color: "orange", icon: "fas fa-heart" },
    { name: "Charisma", key: "charisma" as keyof Character, color: "pink", icon: "fas fa-comments" },
  ];

  const specialStats = [
    { name: "Stealth", key: "stealth" as keyof Character, icon: "fas fa-mask" },
    { name: "Intimidation", key: "intimidation" as keyof Character, icon: "fas fa-skull" },
    { name: "Persuasion", key: "persuasion" as keyof Character, icon: "fas fa-handshake" },
    { name: "Luck", key: "luck" as keyof Character, icon: "fas fa-dice" },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Edit Toggle */}
      {isMaster && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl font-bold text-fantasy-gold">
              Character Stats & Level
            </CardTitle>
            <Button
              variant={isEditing ? "destructive" : "outline"}
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? "Cancel" : "Edit"}
            </Button>
          </CardHeader>
        </Card>
      )}

      {/* Character Level & Duelist Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg text-fantasy-gold">Character Level</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              {isEditing && isMaster ? (
                <Input
                  type="number"
                  value={character.level}
                  onChange={(e) => handleUpdateStat("level", parseInt(e.target.value))}
                  className="text-center text-2xl font-bold"
                  min="1"
                  max="100"
                />
              ) : (
                <div className="text-3xl font-bold text-fantasy-gold">{character.level}</div>
              )}
              <p className="text-sm text-muted-foreground mt-1">Current Level</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg text-fantasy-gold">Duelist Rank</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-2">
              {isEditing && isMaster ? (
                <Select 
                  value={character.duelistRank || "Unranked"} 
                  onValueChange={(value) => handleUpdateStat("duelistRank", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="S">S</SelectItem>
                    <SelectItem value="A">A</SelectItem>
                    <SelectItem value="B">B</SelectItem>
                    <SelectItem value="C">C</SelectItem>
                    <SelectItem value="D">D</SelectItem>
                    <SelectItem value="Unranked">Unranked</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <Badge className={getRankColor(character.duelistRank || 'Unranked')} variant="outline">
                  {character.duelistRank || 'Unranked'}
                </Badge>
              )}
              <div className="text-sm text-muted-foreground">
                Points: {character.duelistPoints || 0}
              </div>
              {isEditing && isMaster && (
                <Input
                  type="number"
                  value={character.duelistPoints || 0}
                  onChange={(e) => handleUpdateStat("duelistPoints", parseInt(e.target.value))}
                  placeholder="Duelist Points"
                  min="0"
                />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg text-fantasy-gold">Arena Ranking</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              {isEditing && isMaster ? (
                <Select 
                  value={character.arenaRanking} 
                  onValueChange={(value) => handleUpdateStat("arenaRanking", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {arenaRankings.map((rank) => (
                      <SelectItem key={rank} value={rank}>{rank}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Badge variant="outline" className="text-lg px-3 py-1">
                  {character.arenaRanking}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Power and Lore Bars */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-r from-red-50 to-orange-50 rounded-xl shadow-lg border border-red-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold text-red-700 flex items-center gap-2">
              <i className="fas fa-fire"></i>
              Power Level
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-red-600">Level</span>
              {isEditing && isMaster ? (
                <Input
                  type="number"
                  value={character.powerLevel}
                  onChange={(e) => handleUpdateStat("powerLevel", parseInt(e.target.value))}
                  className="w-20 text-center"
                  min="1"
                  max="1000"
                />
              ) : (
                <span className="text-xl font-bold text-red-700">{character.powerLevel}</span>
              )}
            </div>
            <Progress value={powerProgress} className="h-3 bg-red-100" />
            <div className="text-xs text-red-600 text-center">
              {character.powerLevel}/1000
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl shadow-lg border border-purple-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold text-purple-700 flex items-center gap-2">
              <i className="fas fa-book"></i>
              Lore Level
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-purple-600">Level</span>
              {isEditing && isMaster ? (
                <Input
                  type="number"
                  value={character.loreLevel}
                  onChange={(e) => handleUpdateStat("loreLevel", parseInt(e.target.value))}
                  className="w-20 text-center"
                  min="1"
                  max="1000"
                />
              ) : (
                <span className="text-xl font-bold text-purple-700">{character.loreLevel}</span>
              )}
            </div>
            <Progress value={loreProgress} className="h-3 bg-purple-100" />
            <div className="text-xs text-purple-600 text-center">
              {character.loreLevel}/1000
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Core Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Core Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {coreStats.map((stat) => {
              const statValue = character[stat.key] as number;
              return (
                <div key={stat.key} className="space-y-2">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <i className={stat.icon}></i>
                    {stat.name}
                  </Label>
                  {isEditing && isMaster ? (
                    <Input
                      type="number"
                      value={statValue}
                      onChange={(e) => handleUpdateStat(stat.key, parseInt(e.target.value))}
                      min="0"
                      max="100"
                    />
                  ) : (
                    <div className="space-y-1">
                      <Progress value={statValue} className="h-2" />
                      <div className="text-xs text-center font-medium">
                        {statValue}%
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Special Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Special Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {specialStats.map((stat) => {
              const statValue = character[stat.key] as number;
              return (
                <div key={stat.key} className="space-y-2">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <i className={stat.icon}></i>
                    {stat.name}
                  </Label>
                  {isEditing && isMaster ? (
                    <Input
                      type="number"
                      value={statValue}
                      onChange={(e) => handleUpdateStat(stat.key, parseInt(e.target.value))}
                      min="0"
                      max="100"
                    />
                  ) : (
                    <div className="space-y-1">
                      <Progress value={statValue} className="h-2" />
                      <div className="text-xs text-center font-medium">
                        {statValue}%
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Character Traits */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Character Traits</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              {character.traits && character.traits.length > 0 ? (
                character.traits.map((trait, index) => (
                  <Badge key={index} variant="secondary">
                    {trait}
                  </Badge>
                ))
              ) : (
                <p className="text-muted-foreground">No traits defined</p>
              )}
            </div>
            {isEditing && isMaster && (
              <div className="border-t pt-3">
                <p className="text-sm text-muted-foreground mb-2">
                  Traits are managed in the Advanced tab
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Skills */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Skills</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {character.skills && Object.keys(character.skills).length > 0 ? (
              Object.entries(character.skills).map(([skill, description]) => (
                <div key={skill} className="flex items-center justify-between p-2 border rounded">
                  <span className="font-medium">{skill}</span>
                  <span className="text-sm text-muted-foreground">{description}</span>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No skills developed</p>
            )}
            {isEditing && isMaster && (
              <div className="border-t pt-3">
                <p className="text-sm text-muted-foreground">
                  Skills are managed in the Advanced tab
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Custom Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg text-fantasy-gold">Custom Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {character.customStats && Object.keys(character.customStats).length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(character.customStats).map(([statName, value]) => (
                  <div key={statName} className="space-y-2">
                    <Label className="text-sm font-medium">{statName}</Label>
                    {isEditing && isMaster ? (
                      <Input
                        type="number"
                        value={value}
                        onChange={(e) => handleUpdateCustomStat(statName, parseInt(e.target.value))}
                        min="0"
                        max="100"
                      />
                    ) : (
                      <div className="space-y-1">
                        <Progress value={value} className="h-2" />
                        <div className="text-xs text-center font-medium">{value}%</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No custom stats defined</p>
            )}

            {/* Add Custom Stat */}
            {isEditing && isMaster && (
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-medium">Add Custom Stat</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Stat name"
                    value={newStatName}
                    onChange={(e) => setNewStatName(e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Value (0-100)"
                    value={newStatValue}
                    onChange={(e) => setNewStatValue(e.target.value)}
                    min="0"
                    max="100"
                  />
                </div>
                <Button onClick={handleAddCustomStat} className="w-full">
                  Add Custom Stat
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}